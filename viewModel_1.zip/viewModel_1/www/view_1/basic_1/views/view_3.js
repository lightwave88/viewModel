(() => {
  const $options_0 = {
    data() {
      return {
        childs: [{
            name: 'a',
            age: 20,
          },
          {
            name: 'b',
            age: 50,
          },
        ],
      }
    },
    $render() {
      debugger;

      const $data = this.$data;
      let content = '<div>';
      for (let i = 0; i < $data.childs.length; i++) {
        let d = $data.childs[i];

        // 重點
        // 重點
        let view = this.$includeView('a', 'child', d, {
          index: i
        });
        content += view.$getIndex();
      }
      content += '</div>';
      this.$out(content);
    },
    reverseData() {
			debugger;
			this.$data.childs.reverse();
			this.$commit();
    }
  };
  //////////////////////////////
  const $options_1 = {
    el: 'div',
    $render() {
      debugger;

      const $data = this.$data;
      let content = `<p>index = ${$data.index}</p>`;
      content += `<p>name = ${$data.name}</p>`;
      content += `<p>age = ${$data.age}</p>`;
      this.$out(content);
    }
  };
  //////////////////////////////
  $bb.view.add('parent', $options_0);
  $bb.view.add('child', $options_1);
})();
