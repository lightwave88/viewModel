(() => {
	let $options_0 = {
		data() {
			return {
				name: 'xyz',
				age: 20,
			};
		},
		$render() {
			debugger;
			let content = '<div>';
			content += '<p>hi....</p>';
			let res = JSON.stringify(this.$data);
			content += `<p>${res}</p>`;
			content += '<p>end</p>';
			content += '</div>';

			this.$print(content);
		}
	};

	$bb.view.add('a', $options_0);
})();
