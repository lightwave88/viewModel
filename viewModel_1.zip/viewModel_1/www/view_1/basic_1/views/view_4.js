(() => {
  const $options_0 = {
    data() {
      return {
        childs: [{
          name: 'a',
          age: 20,
        },
        {
          name: 'b',
          age: 50,
        }],
      }
    },
    $render() {
      debugger;

      const $data = this.$data;
      let content = '<div>';
      for (let i = 0; i < $data.childs.length; i++) {
        let d = $data.childs[i];
        let view = this.$includeView('a', 'child', d);
        content += view.$getIndex();
      }
      content += '</div>';
      this.$out(content);
    },
    reverseData() {
      debugger;
      this.$data.childs.reverse();
      this.$commit();
    }
  };
  //////////////////////////////
  const $options_1 = {
    el: 'div',
    $render() {
      debugger;
      const $sdom = this.$attachShadow();

      const $data = this.$data;
      let content = `<div>
      <p>name = ${$data.name}</p>
      <p>age = ${++$data.age}</p>
      </div>`;

      let dom = document.createElement('div');
      $sdom.appendChild(dom);
      dom.innerHTML = content;
      //-------------
      dom = document.createElement('button');
      $sdom.appendChild(dom);
      dom.textContent = 'changeAge'
      dom.addEventListener('click', (e) => {
        debugger;
        this.changeAge();
      });
    },
    changeAge() {
      let age = $randomValue(1, 100);
      this.$data.age = age;
      this.$commit();
    },
  };
  //////////////////////////////
  $bb.view.add('parent', $options_0);
  $bb.view.add('child', $options_1);
})();
