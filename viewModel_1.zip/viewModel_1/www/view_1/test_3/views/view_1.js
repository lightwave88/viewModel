let $data = {
	value: 5,
	child: {
		value: 10
	}
};

let $options_0 = {
	$render() {
		debugger;

    let data = this.data;
    let content = `<div>parent.value = ${data.value}</div>`;
    let view = this.$includeView(data.child, 'child_1');
    debugger;
    content += view.$getIndex();
    this.$out(content);
	}
}

let $options_1 = {
	el: 'div',
	$render() {
		debugger;
		let data = this.data;
    let content = `<div>child.value = ${data.value}</div>`;
    this.$out(content);
	}
}

$bb.view.add('child_1', $options_1);
