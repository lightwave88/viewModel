// 測試交互作用
let $data = {
	value: 300,
	child: {
		name: 'x',
		age: 18,
	}
};

const $options_0 = {
	$render() {
		debugger;
		let data = this.data;

		let content = '<div>head</div>';
		content += `<p>value = ${data.value}</p>`;
		content += '<hr>';

		// 最主要在測試 props
		let view = this.includeView(data.child, 'child_1');
		debugger;
		content += view.tempRender();

		content += '<div>foot</div>';

		this.write(content);
	},
	changeValue() {
		debugger;
		this.data.value = $randomValue(200, 500);
		this.commit();
	}
}
//----------------------------
const $options_1 = {
	el: 'div',
	$render() {
		debugger;
		const shadow = this.$attachShadow();
		const data = this.data;
		const parentData = this.model.rootData;

		let dom = document.createElement('div');

		let content = '<div><p>child</p>';
		content += `<p>parent.value = ${parentData.value}</p>`;
		content += `<p>name = ${data.name}</p>`;
		content += `<p>age = ${data.age}</p>`;
		content += '</div>';

		dom.innerHTML = content;
		shadow.appendChild(dom);
		//-------------
		dom = document.createElement('button');
		dom.textContent = 'changeChildAge';

		dom.addEventListener('click', () => {
			this.click_1();
		});

		shadow.appendChild(dom);
	},
	click_1() {
		debugger;
		this.data.age = $randomValue(1, 50);
		this.commit();
	}
};
//----------------------------
debugger;
// $bb.view.add('parent_1', $options_0);
$bb.view.add('child_1', $options_1);
