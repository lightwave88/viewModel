// 測試交互作用
let $data = {
	childs: [{
			name: 'x',
			value: 18,
		},
		{
			name: 'y',
			value: 50,
		}
	]
};

const $options_0 = {
	$render() {
		debugger;
		let data = this.data;
		let content = '<div>head</div>';

		for (let i = 0; i < data.childs.length; i++) {
			debugger;
			let d = data.childs[i];

			// here
			d.index = i;

			let view = this.includeView(d, 'child_1');
			debugger;
			content += view.tempRender();
		}
		content += '<div>foot</div>';

		this.write(content);
	}
}
//----------------------------
const $options_1 = {
	el: 'div',
	$render() {
		debugger;
		let data = this.data;

		let content = '<div>';
		content += `<p>name = ${data.name}</p>`;
		content += `<p>value = ${data.value}</p>`;
		content += `<p>index = ${data.index}</p>`;
		content += '</div>';

		this.write(content);
	}
};
//----------------------------
debugger;
// $bb.view.add('parent_1', $options_0);
$bb.view.add('child_1', $options_1);
