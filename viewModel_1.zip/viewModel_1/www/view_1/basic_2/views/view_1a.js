(() => {
	let $options_1 = {
		el: 'div',
		$render() {
			debugger;
			let content = '<div>';
			content += '<p>child</p>';
			content += `<p>name = ${this.data.name}</p>`
			content += `<p>age = ${this.data.age}</p>`;
			content += '</div>';
			content += '<hr>';
			let {
				content: content_1
			} = this.$includeView('child_2', '', this.data.child);
			content += content_1;
			content += '<hr>';

			this.$print(content);
		}
	};

	$bb.view.add('child_1', $options_1);

})();

(() => {
	let $options_1 = {
		el: 'div',
		$render() {
			debugger;
			let content = '<div>';
			content += '<p>child</p>';
			content += `<p>name = ${this.data.name}</p>`
			content += `<p>age = ${this.data.age}</p>`;
			content += '</div>';

			this.$print(content);
		}
	};

	$bb.view.add('child_2', $options_1);
})();
