(() => {
	let $options_0 = {
		el: 'div',
		$render() {
			debugger;
			let content = '<div>';
			content += '<p>child</p>';
			content += `<p>age = ${this.data.age}</p>`;
			content += '</div>';

			this.$print(content);
		}
	};

	$bb.view.add('a', $options_0);
})();
