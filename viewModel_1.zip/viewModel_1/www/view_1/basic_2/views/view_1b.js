(() => {
	let $options_0 = {
		el: 'div',
		$render() {
			debugger;
			const $parent = this.$parent;
			let content = '<div>';

			// 引用 parent.data
			content += `<p>father.age = ${$parent.data.age}</p>`;
			content += '<p>child:</p>';
			content += `<p>age = ${this.data.age}</p>`;
			content += '</div>';

			this.$print(content);
		}
	};

	$bb.view.add('a', $options_0);
})();
