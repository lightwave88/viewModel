debugger;
import $bb from '/my_modules/bb_core/index.js';
//-----------------------
import {
  handle as h_modelView
} from '/my_modules/model_view/index.js';
h_modelView($bb);
//-----------------------
window['$bb'] = $bb;
debugger;
