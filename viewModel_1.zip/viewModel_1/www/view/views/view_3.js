(() => {
	let $options_1 = {
		$render() {
			debugger;
			const data = this.$data;
			let content = '<div>';
			content += `<p>name = ${data.name}</p>`;
			content += `<p>age = ${data.age}</p>`;
			content += '</div>';
			//-------------
			for (let i = 0; i < data.childs.length; i++) {
				content += '<hr>';

				let d = data.childs[i];
				content += this.$includeViewContent(d, 'child');
			}
			this.$print(content);
		}
	};
	//------------------
	let $options_2 = {
		$el: 'div',
		$render() {
			debugger;
			const data = this.$data;
			let content = '<div>';
			content += `<p>name = ${data.name}</p>`;
			content += `<p>age = ${data.age}</p>`;
			content += '</div>';
			this.$print(content);
		}
	};
	//------------------
	$bb.view.add('parent', $options_1);
	$bb.view.add('child', $options_2);
})();
