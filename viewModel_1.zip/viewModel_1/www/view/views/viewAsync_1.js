debugger;
(() => {
	let options_1 = {
		$render() {
			debugger;
			const data = this.$data;
			let content = '<div>';
			content += `<p>name = ${data.name}</p>`;
			content += `<p>age = ${data.age}</p>`;
			content += '</div>';
			debugger;
			this.$print(content);
		},
		$end() {
			console.log('view end');
		}
	};
	//-------------
	debugger;
	$bb.view.add('view', options_1, true);
})();
