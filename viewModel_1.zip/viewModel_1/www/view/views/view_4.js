(() => {
	let $options_1 = {
		$render() {
			debugger;
			const data = this.$data;
			let content = '<h4>template 1</h4>';
			content += '<div>';
			content += `<p>name = ${this.$prop.name}</p>`;
			content += `<p>age = ${data.age}</p>`;
			content += `<p>area = ${data.area}</p>`;
			content += '</div>';
      //-------------
			this.$print(content);
		}
	};
	//------------------
	let $options_2 = {
		$el: 'div',
		$render() {
			debugger;
			const data = this.$data;
			let content = '<h4>template 2</h4>';
			content += '<div>';
			content += `<p>name = ${this.$prop.name}</p>`;
			content += `<p>age = ${data.age}</p>`;
			content += `<p>area = ${data.area}</p>`;
			content += '</div>';
			this.$print(content);
		}
	};
	//------------------
	$bb.view.add('view_1', $options_1);
	$bb.view.add('view_2', $options_2);
})();
