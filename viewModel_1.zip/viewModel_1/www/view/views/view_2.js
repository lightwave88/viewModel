(() => {
	debugger;

	let options_1 = {
		$render() {
			debugger;
			const data = this.$data;
			let content = '<div>';
			content += `<p>id = ${this.$id}</p>`;
			content += `<p>name = ${data.name}</p>`;
			content += `<p>age = ${data.age}</p>`;
			content += '</div><hr>';

			content += this.$includeViewContent(data.child, 'child');

			debugger;
			this.$print(content);
		},
		$end() {
			// alert('parent end');
		}
	};
	//-----------------------
	let options_2 = {
		$el: 'div',
		$render() {
			debugger;
			const data = this.$data;
			let content = '<div>';
			content += `<p>id = ${this.$id}</p>`;
			content += `<p>name = ${data.name}</p>`;
			content += `<p>age = ${data.age}</p>`;
			content += '</div>';
			this.$print(content);
		},
	};
	//-----------------------
	$bb.view.add('parent', options_1);
	$bb.view.add('child', options_2);
})();
