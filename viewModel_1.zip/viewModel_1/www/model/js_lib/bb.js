// debugger;
import $bb from '/my_modules/bb_core/index.js';

import {
	handle as h_viewModel
} from '/my_modules/model_view/index.js';
h_viewModel($bb);

window['$bb'] = $bb;
