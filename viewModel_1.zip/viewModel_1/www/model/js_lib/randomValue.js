window['$randomValue'] = function(value1, value2 = null) {

	let start = 0
	let range;
	let value;

	if (value2 != null) {
		start = value1;
		if (value2 <= value1) {
			throw new Error('...');
		}
		range = value2 - value1;
		value = start + Math.random() * range;
		value = Math.floor(value);
	} else {
		range = value1;
		value = Math.random() * range;
		value = Math.floor(value);
	}
	return value;
};
