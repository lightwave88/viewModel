const $bb = window['$bb'];

const View_1 = $bb.view.extend({
	render($model) {
		console.log(`......parent(${this.$id}) render()`);
		debugger;
		for (let i = 0; i < this.data.childs.length; i++) {
			debugger;
			let d = this.data.childs[i];
			let _d = $model.getRawData(d)
			let childView = this.createView('b', d, {
				key: 'id'
			});
			this.el.appendChild(childView.el);

			console.dir(this);
		}
	},
});
/////////////////////////////////////////////
const View_2 = $bb.view.extend({
	init() {
		debugger;
		let el = document.createElement('div');
		el.setAttribute('class', 'item');
		this.el = el;
	},
	render() {
		console.log(`......child(${this.$id}) render()`);
		debugger;
		let data = this.data;

		let {
			id,
			name,
			age,
		} = data;

		let content = `
    <p>id = ${id}</p>
    <p>name = ${name}</p>
    <p>age = ${age}</p>`;

		this.el.innerHTML = content;
	},
});

debugger;
$bb.view.add('a', View_1);
$bb.view.add('b', View_2);

export default undefined;
