debugger;
import $bb from '/my_modules/bb_core/index.js';
//------------------
window['$bb'] = $bb;
