(() => {
  const options_1 = {
    data() {
      let data = {
        age: 18
      };
      return data;
    },
    $dataUpdate() {
      debugger;
      let res = JSON.stringify(this.model);
      this.$print(res);
    },
    changeAge() {
      debugger;
      this.data.age = $randomValue(10, 50);
      this.model.commit();
    }
  };
  //-------------
  $bb.view.add('a', options_1);
})();
