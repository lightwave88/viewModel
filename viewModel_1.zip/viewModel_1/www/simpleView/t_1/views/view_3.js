(() => {
  const options_1 = {
    data() {
      let data = {
        name: 'parent',
        age: 15,
        childs: [{
            id: 1,
            name: 'x',
            age: 20,
            //-------------
            childs: [{
                id: 'child_1',
                name: 'child_1',
                age: 20,
              },
              {
                id: 'child_2',
                name: 'child_2',
                age: 30,
              }
            ]
            //-------------
          },
          {
            id: 2,
            name: 'y',
            age: 30,
            //-------------
            childs: [{
                id: 'child_3',
                name: 'child_3',
                age: 20,
              },
              {
                id: 'child_4',
                name: 'child_4',
                age: 30,
              }
            ]
            //-------------
          }
        ]
      };
      return data;
    },
    $dataUpdate() {
      debugger;
      let data = this.data;
      let content = '';
      content += `parent: name = ${data.name}, age = ${data.age}\n`;

      for (let i = 0; i < data.childs.length; i++) {
        debugger;
        let d = data.childs[i];
        let child = this.$includeView(d, 'child_1');
        content += child.$out(this);
      }
      this.$print(content);
    },
    updateChildsByID() {
      let data = JSON.parse(JSON.stringify(this.data));
      debugger;
      let list = data.childs;
      list.reverse();
      this.model.updateList('childs', list, 'id');
      this.model.commit();
    },
    updateChilds() {
      let data = JSON.parse(JSON.stringify(this.data));
      debugger;
      let list = data.childs;
      list.reverse();
      this.model.updateList('childs', list);
      this.model.commit();
    },
  };
  //-------------
  $bb.view.add('parent', options_1);
  //////////////////////////////
  const options_2 = {
    $dataUpdate() {
      debugger;
      let data = this.data;
      let content = '';
      content += `child_1: name = ${data.name}, age = ${data.age}\n`;

      for (let i = 0; i < data.childs.length; i++) {
        debugger;
        let d = data.childs[i];
        let child = this.$includeView(d, 'child_2');
        content += child.$out(this);
      }
      this.$print(content);
    },
  };
  //-------------
  $bb.view.add('child_1', options_2);
  //////////////////////////////
  const options_3 = {
    $dataUpdate() {
      debugger;
      let data = this.data;
      let content = `child_2: name = ${data.name}, age = ${data.age}\n`;
      this.$print(content);
    }
  };
  //-------------
  $bb.view.add('child_2', options_3);
  //////////////////////////////

})();
