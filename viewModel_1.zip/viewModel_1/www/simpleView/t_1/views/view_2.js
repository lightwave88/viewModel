(() => {
  const options_1 = {
    data() {
      let data = {
        name: 'parent',
        age: 15,
        childs: [{
            id: 1,
            name: 'x',
            age: 20,
          },
          {
            id: 2,
            name: 'y',
            age: 30,
          }
        ]
      };
      return data;
    },
    $dataUpdate() {
      debugger;
      let data = this.data;
      let content = '';
      content += `parent: name = ${data.name}, age = ${data.age}\n`;

      for (let i = 0; i < data.childs.length; i++) {
        debugger;
        let d = data.childs[i];
        let child = this.$includeView(d, 'child');
        content += child.$out(this);
      }
      this.$print(content);
    },
    changeChildAge() {
      debugger;
      let list = this.data.childs;
      if (list[0] != null) {
        let age = list[0].age + 1;
        list[0].age = age;
        this.model.commit();
      }
    },
    updateChildsByID() {
      let data = JSON.parse(JSON.stringify(this.data));
      debugger;
      let list = data.childs;
      list.reverse();
      this.model.updateList('childs', list, 'id');
      this.model.commit();
    },
    updateChilds() {
      let data = JSON.parse(JSON.stringify(this.data));
      debugger;
      let list = data.childs;
      list.reverse();
      this.model.updateList('childs', list);
      this.model.commit();
    },
  };
  //-------------
  $bb.view.add('parent', options_1);
  /////////////////////////////////////////////
  const options_2 = {
    $dataUpdate() {
      debugger;
      let data = this.data;
      let content = `child name = ${data.name}, age = ${data.age}\n`;
      this.$print(content);
    }
  }
  //-------------
  $bb.view.add('child', options_2);
})();
