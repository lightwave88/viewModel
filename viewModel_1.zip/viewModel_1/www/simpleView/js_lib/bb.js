debugger;
import $bb from '/my_modules/bb_core/index.js';

import {
  handle as h_model
} from '/my_modules/model/index.js';
h_model($bb);
//------------------
import {
  handle as h_simpleView
} from '/my_modules/simpleView_1/index.js';
h_simpleView($bb);
//------------------
window['$bb'] = $bb;
