let $MB;

let $UID = 0;

class ViewPrototype {
  $$$id;
  constructor() {
    this.$$$id = 'view_' + $UID++;
  }
}
/////////////////////////////////
export {
  ViewPrototype
};

export function handle(mb) {
  $MB = mb;
  return ViewPrototype;
}
