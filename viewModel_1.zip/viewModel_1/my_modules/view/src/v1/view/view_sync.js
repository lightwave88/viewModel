let $MB;

let $UID = 0;

const $reg_1 = /^\d+$/;

// 測試 view-model 關係用的
// 簡化版
class View_a {
  $$$id;
  $$$model;
  $$$listener;
  //-------------
  $$$childs = new Set();
  $$$temp_childs = new Set();

  $$$includes = new Map();
  $$$temp_includes = new Map();
  //-------------
  $$$el;
  $$$parent;
  $$$callbacks = {
    'render': null,
    'remove': null,
    'end': null,
  };
  $$$isRemove = false;

  $$$contentList = [];

  $$$isInited = false;
  //-----------------------
  constructor(_extends = {}, loader = null, parent = null) {
    debugger;

    const $bb = $MB.get('bb');

    this.$$$id = `view_${$UID++}`;

    if (parent instanceof View_a) {
      this.$$$parent = parent;
    }
    //--------
    _extends = Object.assign({}, _extends);

    this.$_aboutCallBack(_extends);

    this.$_setModel(_extends);

    this.$_setElement(_extends);
    //--------
    // extends
    for (let key in _extends) {
      if (key in this) {
        throw new Error(`double key(${key})`);
      }
      this[key] = _extends[key];
    }
    //--------
    if (this.$$$model == null) {
      throw new Error('no data');
    }
    debugger;
    let effect = this.$$$model.effect({
      context: this,
      update: (args) => {
        let res = this.$_dataUpdate(args);
        debugger;
        return res;
      },
      remove: () => {
        this.$_dataRemove();
      }
    });

    this.$$$listener = effect();
  }
  //-----------------------
  get $id() {
    return this.$$$id;
  }

  get $model() {
    return this.$$$model;
  }

  get $data() {
    return this.$$$model.data;
  }

  get $isRemove() {
    return this.$$$isRemove;
  }

  get $el() {
    return this.$$$el;
  }

  get $parent() {
    return this.$$$parent;
  }

  get $root() {
    let root = this;
    while (true) {
      if (root.$$$parent == null) {
        break;
      }
      root = root.$$$parent;
    }
    return root;
  }
  //-----------------------
  // API
  // setting
  $setModel(data = {}) {
    debugger;
    if (this.$$$model != null) {
      return;
    }
    const $bb = $MB.get('bb');
    this.$$$model = $bb.vModel.create(data);
  }
  //-----------------------
  $remove() {
    debugger;
    const parent = this.$parent;

    if (this.$$$callbacks['remove'] != null) {
      let fun = this.$$$callbacks['remove'];
      fun();
    }
    //-------------
    // childs
    for (let child of this.$$$childs) {
      debugger;
      this.$$$childs.delete(child);
      child.$remove();
    }
    //-------------
    if (parent != null) {
      // 不用
      // parent.$_removeChild(this);
      this.$$$parent = undefined;
    }

    // dom
    this.$el.remove();

    this.$_destroy();
  }
  //-----------------------
  $isEqual(view) {
    if (!(view instanceof View)) {
      throw new TypeError('...');
    }
    return (this.$id == view.$id);
  }
  //-----------------------
  // API
  $includeView(data, loaderName, setData = null) {
    debugger;

    const $api = $MB.get('api');

    let child = this.$_searchCaches(loaderName, data);

    debugger;
    if (child == null) {

      let options = {
        $data: data,
        $innerData: setData,
      };

      let _extends = $api.get(loaderName);
      if (_extends == null) {
        throw new Error('....');
      }

      Object.assign(_extends, options);

      child = View_a.create(_extends, this);
    } else {
      this.$_changeData(child, setData);
    }
    //-------------
    debugger;
    this.$_recordView(loaderName, child);

    let dom = child.$_getViewTag();
    return {
      view: child,
      dom,
    };
  }
  //-----------------------
  $includeViewDom(data, loaderName, setData = null) {
    let {
      dom
    } = this.$includeView(data, loaderName, setData);
    return dom;
  }
  //-----------------------
  $includeViewContent(data, loaderName, setData = null) {
    let {
      dom
    } = this.$includeView(data, loaderName, setData);
    return dom.outerHTML;
  }
  //-----------------------
  $print(text) {
    const $tools = $MB.get('tools');
    text = $tools.toString(text);

    this.$$$contentList.push(text);
  }

  $out(text) {
    this.$print(text);
  }
  //-----------------------
  $commit() {
    this.$$$model.commit();
  }
  //-----------------------
  $_end() {
    debugger;
    if (this.$$$parent != null) {
      this.$end();
    }
  }
  //-----------------------
  $end() {
    debugger;

    if (!this.$$$isInited) {
      this.$$$isInited = true;
    }
    console.log('all view render finish');

    if (this.$$$callbacks['end'] != null) {
      let fun = this.$$$callbacks['end'];
      fun();
    }
  }
  //-----------------------
  // callback
  $_dataUpdate(args) {
    debugger;

    let {
      listener,
      handle,
    } = args;

    let root = this.$root;
    handle.addRoot(root, () => {
      debugger;
      root.$end();
    });
    //-------------
    // reset
    for (let child of this.$$$childs) {
      this.$$$childs.delete(child);
      this.$$$temp_childs.add(child);
    }
    for (let [key, list] of this.$$$includes) {
      this.$$$includes.delete(key);
      // list.clear();
      this.$$$temp_includes.set(key, list);
    }

    this.$$$contentList.length = 0;
    //-------------
    // render
    let fun = this.$$$callbacks['render'];
    if (fun != null) {
      debugger;
      fun.call(this, args);
    }

    debugger;
    this.$_removeNoUsedView();

    this.$_buildDom();

    this.$_end();
  }
  //-----------------------
  // callback
  $_dataRemove() {
    debugger;
    this.$$$isRemove = true;
  }
  //-----------------------
  $_removeChild(view) {
    this.$$$childs.delete(view);
  }
  //-----------------------
  // view_cache
  $_searchCaches(loaderName, data) {
    // debugger;

    const $bb = $MB.get('bb');
    let ob_1 = $bb.vModel.getObserver(data);

    if (ob_1 == null) {
      throw new Error('....');
    }
    //-------------
    let childView = null;

    if (!this.$$$temp_includes.has(loaderName)) {
      return childView;
    }
    let list = this.$$$temp_includes.get(loaderName);

    for (let child of list) {
      // debugger;
      if (child.$isRemove) {
        continue;
      }
      let model = child.$model;
      let ob_2 = model.observer;

      if (ob_2.isEqual(ob_1)) {
        list.delete(child)
        childView = child;
        break;
      }
    }
    if (list.size == 0) {
      this.$$$temp_includes.delete(loaderName);
    }
    // debugger;

    if (childView != null) {
      this.$$$temp_childs.delete(childView);
    }
    //-------------
    return childView;
  }
  //-----------------------
  $_buildDom() {
    debugger;

    const el = this.$el;

    let html = this.$$$contentList.join('');
    el.innerHTML = html;

    for (let view of this.$$$childs) {
      debugger;
      let id = '#' + view.$id;
      let child_el = view.$el;
      let dom = el.querySelector(id);
      if (dom == null) {
        console.log(html);
        throw new Error(`no dom(${id}) `);
      }
      dom.replaceWith(child_el);
    }
  }
  //-----------------------
  $_destroy() {
    let names = Object.getOwnPropertyNames(this);

    while (names.length > 0) {
      let name = names.pop();
      this[name] = undefined;
      delete(this[name]);
    }
  }
  //-----------------------
  // setting
  $_aboutCallBack(options) {
    // debugger;
    for (let key in this.$$$callbacks) {
      let k = '$' + key;
      if (k in options) {
        this.$$$callbacks[key] = options[k];
        delete(options[k]);
      }
    } // for
  }
  //-----------------------
  // setting
  $_setModel(options) {
    debugger;

    const $bb = $MB.get('bb');

    let key = '$innerData';
    let innerData;

    if (key in options) {
      innerData = options[key];
      delete(options[key]);
    }

    if (typeof(innerData) == 'function') {
      innerData = innerData.call(this);
    }
    //-------------
    key = '$data';
    let data;

    if (key in options) {
      let _data = options[key];

      if (typeof(_data) == 'function') {
        data = _data.call(this);
      } else {
        data = _data;
      }
      delete(options[key]);
    }
    //-------------
    debugger;
    let $data = this.$_mergeData(data, innerData);

    debugger;
    this.$setModel($data);
  }
  //-----------------------
  // setting
  $_setElement(options) {
    // debugger;

    let el;
    let key = '$el';

    if (key in options) {
      el = options[key];
      delete(options[key]);
    }

    if (typeof(el) == 'function') {
      let fun = el;
      el = fun.call(this);
    }
    //-------------
    if (typeof(el) == 'string') {
      el = document.createElement(el);
      el.id = this.$$$id;
    }

    if (!(el instanceof HTMLElement)) {
      throw new TypeError('...');
    }

    this.$$$el = el;
  }
  //-----------------------
  // render
  $_getViewTag() {
    // debugger;

    let dom = document.createElement('b-view');
    dom.id = this.$$$id;
    return dom;
  }
  //-----------------------
  // view_cache
  $_recordView(loaderName, view) {
    // debugger;

    this.$$$childs.add(view);

    if (!this.$$$includes.has(loaderName)) {
      this.$$$includes.set(loaderName, new Set());
    }
    let list = this.$$$includes.get(loaderName);
    list.add(view);
  }
  //-----------------------
  // view_cache
  $_removeNoUsedView() {
    // debugger;

    // 移除沒被用到的 view
    for (let child of this.$$$temp_childs) {
      debugger;
      this.$$$temp_childs.delete(child);
      child.$remove();
    }

    for (let [key, list] of this.$$$temp_includes) {
      list.clear();
      this.$$$temp_includes.delete();
    }
  }
  //-----------------------
  // innerData
  $_changeData(view, setData) {
    debugger;

    if (setData == null) {
      return;
    }
    //-------------
    const $tools = $MB.get('tools');
    const $rawData = view.$model.getRawData();
    const $data = view.$model.data;

    if (Array.isArray($rawData)) {

      if (Array.isArray(setData)) {
        while (setData.length > 0) {
          let value = setData.shift();
          $data.push(value);
        }
      } else if ($tools.isPlainObject(setData)) {
        for (let k in setData) {
          debugger;
          if (!$reg_1.test(k)) {
            continue;
          }
          let index = parseInt(k, 10);
          if (index < $rawData.length) {
            $data[index] = setData[k];
          }
        }
      } else {
        throw new TypeError('...');
      }

    } else if ($tools.isPlainObject($rawData)) {

      if (!$tools.isPlainObject(setData)) {
        throw new TypeError('...');
      }
      Object.assign($data, setData);

    } else {
      throw new TypeError('...');
    }
  }
  //-----------------------
  // setting
  $_mergeData(data, innerData) {
    debugger;

    if (innerData == null) {
      return data;
    }
    //-------------
    const $tools = $MB.get('tools');

    // 取得 rawData
    let $rawData = $tools.vModel.getRawData(data);

    if (Array.isArray($rawData)) {
      if (Array.isArray(innerData)) {
        while (innerData.length > 0) {
          let value = innerData.shift();
          $rawData.push(value);
        }
      } else if ($tools.isPlainObject(innerData)) {
        for (let k in innerData) {
          if (!$reg_1.test(k)) {
            continue;
          }
          let index = parseInt(k, 10);
          if (index < $rawData.length) {
            $data[index] = innerData[k];
          }
        }
      } else {
        throw new TypeError('...');
      }
    } else if ($tools.isPlainObject($rawData)) {

      if (!$tools.isPlainObject(innerData)) {
        throw new TypeError('...');
      }
      Object.assign(data, innerData);
    } else {
      throw new TypeError('...');
    }
    return data;
  }
  //-----------------------
}
//////////////////////////////
export function handle(mb) {
  $MB = mb;
  return View_a;
}
