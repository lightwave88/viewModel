import {
	ViewPrototype
} from './viewPrototype.js';

let $MB;

const $reg_1 = /^\d+$/;

// 測試 view-model 關係用的
// 簡化版
class SimpleView extends ViewPrototype {
	$$$id;
	$$$model;
	$$$propOb;
	$$$listener;
	//-------------
	$$$childs = new Set();
	$$$temp_childs = new Set();

	$$$includes = new Map();
	$$$temp_includes = new Map();
	//-------------
	$$$el;
	$$$parent;
	$$$callbacks = {
		'init': null,
		'render': null,
		'remove': null,
		'end': null,
	};
	$$$isRemove = false;

	$$$contentList = [];

	$$$isInited = false;
	//-------------
	// 非同步
	$$$loader;
	//-------------
	$$$pr_loader;
	$$$def_init;
	$$$def_render;
	$$$waitingList = [];
	// $$$isRendering = true;
	//-----------------------
	constructor($extends = {}, loader = null, parent = null) {
		debugger;
		super();

		const $bb = $MB.get('bb');

		this.$$$def_init = $bb.$deferred();

		if (parent != null) {
			if (parent instanceof SimpleView) {
				this.$$$parent = parent;
			} else {
				throw new TypeError('...');
			}
		}
		//--------
		let setting = this.$_aboutSettingLoad(loader);
		//--------
		$extends = Object.assign({}, setting, $extends);

		this.$_init($extends);

		// 等待 loader
		this.$_initAsync($extends);
	}
	//-----------------------
	get $id() {
		return this.$$$id;
	}

	get $model() {
		return this.$$$model;
	}

	get $data() {
		return this.$$$model.data;
	}

	get $prop() {
		return this.$$$propOb.data;
	}

	get $el() {
		return this.$$$el;
	}

	get $parent() {
		return this.$$$parent;
	}

	get $root() {
		let root = this;
		while (true) {
			if (root.$$$parent == null) {
				break;
			}
			root = root.$$$parent;
		}
		return root;
	}
	//-----------------------
	$renderPromise() {
		let pr = this.$$$def_render.promise;
		return pr;
	}

	$initPromise() {
		let pr = this.$$$def_init.promise;
		return pr;
	}
	//-----------------------
	// API
	// setting
	$setModel(data = {}) {
		debugger;
		if (this.$$$model != null) {
			return;
		}
    const $bb = $MB.get('bb');
		this.$$$model = $bb.vModel.create(data);
	}
	//-----------------------
	$remove() {
		debugger;

		if (this.$$$callbacks['remove'] != null) {
			let fun = this.$$$callbacks['remove'];
			fun();
		}
		//-------------
		// childs
		for (let child of this.$$$childs) {
			debugger;
			this.$$$childs.delete(child);
			child.$remove();
		}
		//-------------
		// dom
		this.$el.remove();

		this.$_destroy();
	}
	//-----------------------
	$isEqual(view) {
		if (!(view instanceof SimpleView)) {
			throw new TypeError('...');
		}
		return (this.$id == view.$id);
	}
	//-----------------------
	// API
	$includeView(loaderName, data, propData = null) {
		debugger;

		const $api = $MB.get('viewApi');
		const $tools = $MB.get('tools');

		let child = this.$_searchCaches(loaderName, data);
		let isNew;

		if (child == null) {
			debugger;
			isNew = true;

			let $extends = {
				$data: data,
			};

			if (propData != null) {
				$extends['$prop'] = propData;
			}

			debugger;
			let loader = $api.get(loaderName);
			if (loader == null) {
				throw new Error('....');
			}
			debugger;
			child = new SimpleView($extends, loader, this);

		} else {
			debugger;
			isNew = false;
			const propOb = child.$$$propOb;

			if (propData != null && !$tools.isPlainObject(propData)) {
				throw new TypeError('...');
			}
			debugger;
			Object.assign(propOb.data, propData);

			if (propOb.isDataChange(true)) {
				debugger;
				child.$$$listener.propUpdate();
			}
		}
		//-------------
		debugger;
		this.$_recordView(loaderName, child, isNew);

		let dom = child.$_getTempContent();
		return {
			view: child,
			dom,
		};
	}
	//-----------------------
	$includeViewDom(loaderName, data, setData = null) {
		let {
			dom
		} = this.$includeView(loaderName, data, setData);
		return dom;
	}
	//-----------------------
	$includeViewContent(loaderName, data, setData = null) {
		let {
			dom
		} = this.$includeView(loaderName, data, setData);
		return dom.outerHTML;
	}

	$isOnCommit() {
		return this.$$$model.isOnCommit();
	}
	//-----------------------
	$print(text) {
		const $tools = $MB.get('tools');
		text = $tools.toString(text);

		this.$$$contentList.push(text);
	}

	$out(text) {
		this.$print(text);
	}
	//-----------------------
	$commit() {
		this.$$$model.commit();
	}
	//-----------------------
	$_render() {
		debugger;

		const el = this.$el;

		let html = this.$$$contentList.join('');
		el.innerHTML = html;

		for (let view of this.$$$childs) {
			debugger;
			let id = '#' + view.$id;
			let child_el = view.$el;
			let dom = el.querySelector(id);
			if (dom == null) {
				console.log(html);
				throw new Error(`no dom(${id}) `);
			}
			dom.replaceWith(child_el);
		}

		this.$_end();
	}
	//-----------------------
	$_buildDom() {
		debugger;
	}
	//-----------------------
	$_end() {
		debugger;

		this.$$$def_render.resolve();
		//--------
		if (this.$$$parent != null) {
			if (!this.$$$isInited) {
				this.$$$isInited = true;
				this.$$$def_init.resolve();
			}
		} else {
			if (!this.$$$isInited) {
				debugger;
				this.$$$isInited = true;
				this.$$$def_init.resolve();
				this.$$$model.commit();
			}
			return;
		}
	}
	//-----------------------
	$_endCallback() {
		debugger;
		if (this.$$$callbacks['end'] != null) {
			let fun = this.$$$callbacks['end'];
			fun();
		}
	}
	//-----------------------
	// callback
	$_dataUpdate(args) {
		debugger;
		const $bb = $MB.get('bb');

		let {
			listener,
			handle,
		} = args;
		//-------------
		if (this.$$$def_render.state != 'pending') {
			// not init
			this.$$$def_render = $bb.$deferred();
		}

		let root = this.$root;
		handle.addRoot(root, () => {
			debugger;
			root.$_endCallback();
		});
		//-------------
		debugger;

		// reset
		for (let child of this.$$$childs) {
			this.$$$childs.delete(child);
			this.$$$temp_childs.add(child);
		}
		for (let [key, list] of this.$$$includes) {
			this.$$$includes.delete(key);
			// list.clear();
			this.$$$temp_includes.set(key, list);
		}

		this.$$$contentList.length = 0;
		//-------------
		// render
		let fun = this.$$$callbacks['render'];
		if (fun != null) {
			debugger;

			try {
				fun.call(this, args);
			} catch (e) {
				console.dir(e);
				throw e;
			}
		}
		debugger;
		this.$_removeNoUsedView();
		//-------------
		let pr = Promise.all(this.$$$waitingList);

		pr.then(() => {
			debugger;
			this.$$$waitingList.length = 0;
			this.$_render();
		}, (er) => {
			debugger;
			throw er;
		});

		debugger;
		return this.$$$def_render.promise;
	}
	//-----------------------
	// callback
	$_dataRemove() {
		debugger;
		this.$$$isRemove = true;
	}
	//-----------------------
	$_removeChild(view) {
		this.$$$childs.delete(view);
	}
	//-----------------------
	// view_cache
	$_searchCaches(loaderName, data) {
		// debugger;

		const $bb = $MB.get('bb');
		let ob_1 = $bb.vModel.getObserver(data);

		if (ob_1 == null) {
			throw new Error('....');
		}
		//-------------
		let childView;

		if (!this.$$$temp_includes.has(loaderName)) {
			return null;
		}
		let list = this.$$$temp_includes.get(loaderName);

		for (let child of list) {
			// debugger;
			if (child.$$$isRemove) {
				continue;
			}
			let model = child.$model;
			let ob_2 = model.observer;

			if (ob_2.isEqual(ob_1)) {
				list.delete(child)
				childView = child;
				break;
			}
		}
		if (list.size == 0) {
			this.$$$temp_includes.delete(loaderName);
		}
		// debugger;

		if (childView != null) {
			this.$$$temp_childs.delete(childView);
		}
		//-------------
		return childView;
	}
	//-----------------------
	$_destroy() {
		let names = Object.getOwnPropertyNames(this);

		while (names.length > 0) {
			let name = names.pop();
			this[name] = undefined;
			delete(this[name]);
		}
	}
	//-----------------------
	// setting
	$_aboutCallBack(options) {
		// debugger;
		for (let key in this.$$$callbacks) {
			let k = '$' + key;
			if (k in options) {
				this.$$$callbacks[key] = options[k];
				delete(options[k]);
			}
		} // for
	}
	//-----------------------
	// setting
	$_setModel(options) {
		// debugger;

		if (this.$$$model != null) {
			return;
		}
		const $tools = $MB.get('tools');
		const $bb = $MB.get('bb');

		let key = '$data';
		let data;

		if (key in options) {
			data = options[key];
			delete(options[key]);
			//-------------
			debugger;
			const ModelClass = $bb.vModel.getModelClass();

			while (true) {
				debugger;
				if (typeof(data) == 'function') {
					data = data.call(this);
					continue;
				} else if (data instanceof ModelClass) {
					break;
				} else if ($tools.isPlainObject(data)) {
					break;
				} else {
					throw new TypeError('...');
				}
			}
			//--------
			debugger;
			// this.$_mergeData(data, innerData);

			debugger;
			this.$setModel(data);
		}
	}
	//-----------------------
	$_setProp(options) {

		const $bb = $MB.get('bb');
		const $tools = $MB.get('tools');

		let propData = {};
		let propKey = '$prop';

		if (propKey in options) {
			let data = options[propKey];
			delete(options[propKey]);

			if (!$tools.isPlainObject(data)) {
				console.dir(data);
				throw new TypeError('...')
			}
			Object.assign(propData, data);
		}
		debugger;
		this.$$$propOb = $bb.vModel.$_createProp(propData);
	}
	//-----------------------
	// setting
	$_setElement(options) {
		// debugger;

		let el;
		let key = '$el';

		if (key in options) {
			el = options[key];
			delete(options[key]);
		} else {
			return;
		}

		while (true) {
			// debugger;
			if (typeof(el) == 'function') {
				let fun = el;
				el = fun.call(this);
				continue;
			}
			if (typeof(el) == 'string') {
				el = document.createElement(el);
				el.id = this.$$$id;
				continue;
			}
			if (el instanceof HTMLElement) {
				break;
			}
			throw new TypeError('...');
		}
		//-------------
		// debugger;
		this.$$$el = el;
	}
	//-----------------------
	// render
	$_getTempContent() {
		// debugger;
		let dom = document.createElement('b-view');
		dom.id = this.$$$id;
		return dom;
	}
	//-----------------------
	// view_cache
	$_recordView(loaderName, view, isNew) {
		debugger;

		let pr = view.$initPromise();
		this.$$$waitingList.push(pr);

		this.$$$childs.add(view);

		if (!this.$$$includes.has(loaderName)) {
			this.$$$includes.set(loaderName, new Set());
		}
		let list = this.$$$includes.get(loaderName);
		list.add(view);
	}
	//-----------------------
	// view_cache
	$_removeNoUsedView() {
		// debugger;

		// 移除沒被用到的 view
		for (let child of this.$$$temp_childs) {
			debugger;
			this.$$$temp_childs.delete(child);
			child.$remove();
		}

		for (let [key, list] of this.$$$temp_includes) {
			list.clear();
			this.$$$temp_includes.delete();
		}
	}
	//-----------------------
	$_init($extends) {
		debugger;

		const $bb = $MB.get('bb');

		this.$$$def_render = $bb.$deferred();

		this.$_aboutCallBack($extends);
		//--------
		this.$_setElement($extends);
		//--------
		this.$_setModel($extends);

		this.$_setProp($extends);
		//--------
		// init
		let pr;
		let initFn = this.$$$callbacks['init'];
		if (initFn != null) {
			pr = initFn.call(this);
		}
		return pr;
	}
	//-----------------------
	async $_initAsync($extends) {
		debugger

		if (this.$$$pr_loader instanceof Promise) {
			let setting = await this.$$$pr_loader;

			$extends = Object.assign({}, setting, $extends);

			debugger;
			this.$_setElement($extends);

			this.$_aboutCallBack($extends);
		}
		//--------
		debugger;

		// extends
		for (let key in $extends) {
			if (key in this) {
				throw new Error(`double key(${key})`);
			}
			this[key] = $extends[key];
		}
		//--------
		// 最後檢查
		this.$_initCheck();

		debugger;
		const effect = this.$$$model.effect({
			context: this,
			update: (args) => {
				let pr = this.$_dataUpdate(args);
				debugger;
				return pr;
			},
			remove: () => {
				this.$_dataRemove();
			}
		});

		this.$$$listener = effect();
	}
	//-----------------------
	// init 最後的檢查
	$_initCheck() {
		const ModelClass = $bb.vModel.getModelClass();

		if (this.$$$model == null) {
			throw new Error('no model');
		}
		if (!(this.$$$model instanceof ModelClass)) {
			throw new TypeError('view.model typeError');
		}

		if (!(this.$$$el instanceof HTMLElement)) {
			throw new Error('view.el error');
		}

		if (typeof(this.$$$callbacks.render) != 'function') {
			console.log('no view.render()');
		}
	}
	//-----------------------
	// setting
	$_aboutSettingLoad(loader) {

		const ViewSetting = $MB.get('ViewSetting');
		const $bb = $MB.get('bb');

		let setting = {};

		if (loader != null) {
			if (!(loader instanceof ViewSetting)) {
				throw new TypeError('...');
			}
			if (loader.isAsync) {
				this.$$$pr_loader = loader.promise;
			} else {
				Object.assign(setting, loader.setting)
			}
		}
		return setting;
	}
	//-----------------------
	/*
	 $_noticeParent(pr) {
	 debugger;
	 const parent = this.$parent;
	 if (parent == null) {
	 return;
	 }
	 if (parent.$$$waitingList == null) {
	 // parent 沒有執行 render
	 return;
	 }
	 parent.$$$waitingList.add(pr);
	 }
	 */
}
//////////////////////////////
export function handle(mb) {
	$MB = mb;
	return SimpleView;
}
