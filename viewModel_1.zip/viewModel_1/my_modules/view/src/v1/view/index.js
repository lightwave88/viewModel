import MB from '../../mb.js';
const $mb = new MB();
//-------------
import {
  handle as h_viewProto
} from './viewPrototype.js';
$mb.importHandle('ViewProto', h_viewProto);
//-------------
import {
  handle as h_view
} from './view.js';
$mb.importHandle('View', h_view);
//-------------
$mb.export(function() {
//  const View_sync = this.get('View_sync');
  const View = this.get('View');
  const ViewProto = this.get('ViewProto')
  return {
    View,
    ViewProto
  };
});

export default $mb;
