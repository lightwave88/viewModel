import MB from '../mb.js';
const $mb = new MB();
//-------------
import {
  handle as h_api
} from './api.js';
$mb.importHandle('viewApi', h_api);
//-------------
import m_view from './view/index.js';
$mb.importModule(['View', 'ViewProto'], m_view);
//-------------
import m_viewBracket from './viewBracket/index.js';
$mb.importModule(['viewBracket', 'ViewSetting'], m_viewBracket);
//-------------
import {
  handle as h_tools
} from './tools.js';
$mb.importHandle('tools', h_tools);
//-------------
$mb.export(function() {
  // debugger;
  let viewApi = $mb.get('viewApi');
  return viewApi;
});

export default $mb;
