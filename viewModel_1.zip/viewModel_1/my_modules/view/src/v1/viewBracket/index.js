import MB from '../../mb.js';
const $mb = new MB();

import {
	handle as h_bracketSync
} from './viewBracket.js';
$mb.importHandle(['viewBracket', 'ViewSetting'], h_bracketSync);

$mb.export(() => {
	let viewBracket = $mb.get('viewBracket');
	let ViewSetting = $mb.get('ViewSetting');
	return {
		viewBracket,
		ViewSetting
	};
});

export default $mb;
