let $MB;

const $delayTime = 3000;
const $useRandomTime = true;

let $viewBracket_singleton;

class ViewBracket {

  $bracket = {};
  //------------------
  static singleton() {
    if ($viewBracket_singleton == null) {
      $viewBracket_singleton = new ViewBracket();
    }
    return $viewBracket_singleton;
  }
  //------------------
  constructor() {}
  //------------------
  add(name, setting = {}, isAsync) {
    this.$bracket[name] = new ViewSetting(name, setting, isAsync);
  }
  //------------------
  get(name) {
    if (!(name in this.$bracket)) {
      throw new Error('...');
    }
    return this.$bracket[name]
  }
  //------------------
  has(name) {
    return (name in this.$bracket);
  }
}
//////////////////////////////
class ViewSetting {
  $$name;
  $$promise;
  $$setting = {};
  $$isAsync = false;
  //-----------------------
  constructor(name, setting = {}, isAsync) {

    this.$$name = name;

    if (isAsync != null) {
      if (typeof (isAsync) != 'boolean') {
        throw new TypeError('...');
      }
      this.$$isAsync = isAsync;
    }
    if (isAsync) {
      // 模擬非同步

      let time = $useRandomTime ? randomValue($delayTime) : $delayTime;

      this.$$promise = new Promise(($res) => {
        console.log(`loader(${this.$$name}) delay(${time})`);

        setTimeout(() => {
          debugger;
          Object.assign(this.$$setting, setting);
          $res(this.$$setting);
        }, time);
      });
    } else {
      Object.assign(this.$$setting, setting);
  }
  }
  //-----------------------
  get promise() {
    return this.$$promise;
  }
  //-----------------------
  get setting() {
    // 模擬非同步
    return this.$$setting;
  }
  //-----------------------
  get isAsync() {
    return this.$$isAsync;
  }
}
//////////////////////////////

function randomValue(value1, value2 = null) {

  let start = 0
  let range;
  let value;

  if (value2 != null) {
    start = value1;
    if (value2 <= value1) {
      throw new Error('...');
    }
    range = value2 - value1;
    value = start + Math.random() * range;
    value = Math.floor(value);
  } else {
    range = value1;
    value = Math.random() * range;
    value = Math.floor(value);
  }
  return value;
}

export function handle(mb) {
  $MB = mb;
  let viewBracket = ViewBracket.singleton();
  return {
    viewBracket,
    ViewSetting
  };
}
