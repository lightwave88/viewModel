let $MB;

const $viewApi = {
  create(_extends = {}, loader = null, parent = null) {
    debugger;

    const View = $MB.get('View');
    let view = new View(_extends, loader, parent);

    return view;
  },
  createSync(_extends = {}, parent = null) {
    debugger;

    const View = $MB.get('View_sync');
    let view = View.create(_extends, parent);

    return view;
  },
  //-----------------------
  get(name) {
    // debugger;
    const $bracket = $MB.get('viewBracket');
    let res = $bracket.get(name);
    return res;
  },
  // for test
  add(name, _extends, isAsync) {
    // debugger;
    const $bracket = $MB.get('viewBracket');
    $bracket.add(name, _extends, isAsync);
  },
  // for test
  has(name) {
    // debugger;
    const $bracket = $MB.get('viewBracket');
    let res = $bracket.has(name);
    return res;
  },
  //-----------------------
  get tools() {
    let tools = $MB.get('tools');
    return tools;
  }
}

export function handle(mb) {
  $MB = mb;
  return $viewApi;
}
