import {
  ModuleBridge
} from './moduleBridge.js';

const $MB = new ModuleBridge();
//-------------
import {
  handle as h_config
} from './config.js';
$MB.importHandle('config', h_config);

import {
  handle as h_tools
} from './tools.js';
$MB.importHandle('tools', h_tools);

import {
  handle as h_api
} from './api.js';
$MB.importHandle('api', h_api);

import {
  handle as h_ob
} from './Observe.js';
$MB.importHandle('Observe', h_ob);

import {
  handle as h_listenObj
} from './listenObj.js';
$MB.importHandle('ListenObj', h_listenObj);

import {
  handle as h_makeProxy
} from './makeProxy.js';
$MB.importHandle('makeProxy', h_makeProxy);

import {
  handle as h_jobQueue
} from './jobQueue.js';
$MB.importHandle('jobQueue', h_jobQueue);
//-------------
export function handle(bb) {
  $MB.import('bb', bb);
  let api = $MB.get('api');

  bb.store = api;
  bb['$store'] = api;
}
