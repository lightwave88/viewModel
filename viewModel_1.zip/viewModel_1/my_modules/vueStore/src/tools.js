let $MB;

const $tools = {};


$tools.getOb = function(data) {
	const $config = $MB.get('config');
	const ob_attrName = $config['ob_attrName'];

	let ob = null;
	try {
		ob = (data[ob_attrName] || null);
	} catch (e) {}

	return ob;
};

export function handle(mb) {
	$MB = mb;
	return $tools;
}
