let $MB;

const $jobQueue = {
	$jobList: (new Set()),
	$isFlushing: false,
	$p_1: null,
	flush() {
		if (this.$isFlushing) {
			// 避免多次啓動
			return;
		}
		//-------------
		this.$isFlushing = true;

		if (this.$p_1 == null) {
			this.$p_1 = Promise.resolve();
		}
		this.$p_1.then(() => {
			// debugger;
			for (let listener of this.$jobList) {
				debugger;
				listener.$$$dataUpdate();
			}

		}).finally(() => {
			this.$jobList.clear();
			this.$isFlushing = false;
		});
	},
	add(listener) {
		this.$jobList.add(listener);
		this.flush();
	},
};


export function handle(mb) {
	$MB = mb;
	return $jobQueue;
}
