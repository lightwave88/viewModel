let $MB;

// let $active_listener;

// 避免(讀取->修改->讀取->修改)的迴圈
const $listenerStock = [];

const $API = {
  // 取得激活中的 listener
  get listener() {

    if ($listenerStock.length == 0) {
      return null;
    }
    let index = $listenerStock.length - 1;
    return $listenerStock[index];
  },
  //-----------------------
  isActive(listener) {
    let res = $listenerStock.some((l) => {
      return listener.isEqual(l)
    });
    return res;
  },
  //-----------------------
  // 登錄 listener
  addListener(listener) {
    const ListenObj = $MB.get('ListenObj');
    if (!(listener instanceof ListenObj)) {
      throw new TypeError('...');
    }
    $listenerStock.push(listener);
  },
  //-----------------------
  // 移除 listener
  removeListener() {
    $listenerStock.pop();
  },
  //-----------------------
  // 取得可繼承的 class
  getListenerClass() {
    const ListenObj = $MB.get('ListenObj');
    return ListenObj;
  },
  //-----------------------
  // API
  initJob(callback) {
    const ListenObj = $MB.get('ListenObj');
    let listener = new ListenObj(callback);
    listener.$dataUpdate();
    return listener;
  },
  //-----------------------
  // create proxy
  create(data) {
    debugger;
    let $makeProxy = $MB.get('makeProxy');
    let value = $makeProxy(data);
    return value;
  },
  //-----------------------
  // for test
  getObserve(data) {
    debugger;
    const $tools = $MB.get('tools');
    let res = $tools.getOb(data);
    return res;
  }
};

export function handle(mb) {
  $MB = mb;
  return $API;
}
