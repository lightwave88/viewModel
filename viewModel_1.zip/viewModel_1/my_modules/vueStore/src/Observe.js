let $MB;

class Observe {
	$raw;
	$proxy;
	// 記錄有多少物件依賴 data
	$deps = new Map();
	//-----------------------
	constructor(data) {
		// debugger;
		const $bb = $MB.get('bb');

		if (data == null || typeof (data) != 'object') {
			throw new TypeError('...');
		}
		this.$raw = data;
		//-------------

		this._defAttr(this.$raw);
		//-------------
		if (Array.isArray(this.$raw)) {
			this._arrayProxy();
		} else if ($bb.$isPlainObject(this.$raw)) {
			this._plainObjProxy();
		} else {
			throw new TypeError('...');
		}

		return {
			proxy: this.$proxy,
			ob: this,
		};
	}
	//-----------------------
	get deps() {
		return this.$deps;
	}
	//-----------------------
	addListener(key, listener) {
		debugger;
		const ListenObj = $MB.get('ListenObj');
		if (!(listener instanceof ListenObj)) {
			throw new TypeError('...');
		}
		if (!this.$deps.has(key)) {
			this.$deps.set(key, (new Set()));
		}
		let list = this.$deps.get(key);
		list.add(listener);
		//-------------
		listener.$addDeps(list);
		return list;
	}
	//-----------------------
	removeListener(listener) {
		const ListenObj = $MB.get('ListenObj');
		if (!(listener instanceof ListenObj)) {
			throw new TypeError('...');
		}
		if (this.$deps.has(key)) {
			let list = this.$deps.get(key);
			list.delete(listener);

			if (list.size == 0) {
				this.$deps.delete(key);
			}
		}
	}
	//-----------------------
	_defAttr(data) {

		const $config = $MB.get('config');
		const $symbol = $config['ob_attrName'];
		const $this = this;

		Object.defineProperty(data, $symbol, {
			value: $this,
			writable: false,
			configurable: false,
			enumerable: false,
		});
	}
	//-----------------------
	_arrayProxy() {
		// debugger;

		const $this = this;
		const $makeProxy = $MB.get('makeProxy');

		this.$proxy = new Proxy(this.$raw, {
			get(target, key) {
				// GET
				debugger;


			},
			set(target, key, value) {
				debugger;


			},
			has(target, key) {
				// GET
				debugger;


			},
			ownKeys(target) {
				// GET
				debugger;


			},
			deleteProperty(target, key) {
				debugger;

			},
		});
	}
	//-----------------------
	_plainObjProxy() {
		// debugger;

		const $this = this;
		const $makeProxy = $MB.get('makeProxy');
		const $config = $MB.get('config');
		const $rawData_attr = $config['rawData_attr'];

		this.$proxy = new Proxy(this.$raw, {
			get(target, key) {
				debugger;
				let value;
				if (key === $rawData_attr) {
					value = target;
				} else {
					value = target[key];
				}

				$this._plainObj_track(target, key);

				return value;
			},
			set(target, key, value) {
				debugger;

				let lengthChanged = !(key in target);

				value = $makeProxy(value);
				target[key] = value;

				$this._plainObj_trigger(target, key, lengthChanged);

				return true;
			},
			has(target, key) {
				debugger;

				$this._plainObj_track(target, key);

				let res = Reflect.has(target, key);
				return res;
			},
			ownKeys(target) {
				// 攔截 loop
				debugger;
				const $config = $MB.get('config');
				let iterate_key = $config['iterate_key'];

				let keys = Reflect.ownKeys(target);

				$this._plainObj_track(target, iterate_key);

				return keys;
			},
			deleteProperty(target, key) {
				debugger;

				let res = Reflect.deleteProperty(target, key);
				if (!res) {
					return res;
				}
				$this._plainObj_trigger(target, key);
				return res;
			}
		});
	}
	//-----------------------
	_plainObj_track(target, key) {
		debugger;

		const $tools = $MB.get('tools');
		const $api = $MB.get('api');
		const $config = $MB.get('config');
		const $ob_attrName = $config['ob_attrName'];

		// 重點
		let listener = $api.listener;

		(() => {
			debugger;
			if (listener == null) {
				return;
			}
			if (key == 'toJSON') {
				return;
			}
			if (typeof (key) == 'symbol') {
				// 讀取 observe 的 key
				return;
			}
			let ob = $tools.getOb(target);
			if (ob == null) {
				return;
			}
			//-------------
			// 主任務
			ob.addListener(key, listener);
		})();
	}
	//-----------------------
	_plainObj_trigger(target, key, lengthChanged = false) {
		debugger;
		const $tools = $MB.get('tools');
		// const $jobQueue = $MB.get('jobQueue');
		const $config = $MB.get('iterate_key');
		// const $api = $MB.get('api');

		let ob = $tools.getOb(target);
		//-------------
		// 重要使用考背，防止無窮迴圈
		// 重要使用考背，防止無窮迴圈
		let depList = new Set();

		let list = ob.deps.get(key);
		if (list != null) {
			for (let l of list) {
				depList.add(l);
			}
		}
		//-------------
		if (lengthChanged) {
			// 會影響到有監聽長度的 listener
			let iterate_key = $config['iterate_key'];
			list = ob.deps.get(iterate_key);

			if (list != null) {
				for (let l of list) {
					depList.add(l);
				}
			}
		}
		//-------------
		for (let listener of depList) {
			// 數據變動，通知依賴者
			debugger;
			/*
			if ($api.isActive(listener)) {
				continue;
			}
			$jobQueue.add(listener);
			*/
			// 把自己排入工作隊列
			listener.$dataUpdate();
		}
	}
}

export function handle(mb) {
	$MB = mb;
	return Observe;
}
