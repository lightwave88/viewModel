let $MB;

function linkOb(data) {
	// debugger;
	if (data == null || typeof(data) != 'object') {
		return data;
	}
	const Observe = $MB.get('Observe');
	let {
		proxy,
		ob
	} = new Observe(data);
	return proxy;
}
//--------------------------------------
function walkArray(data) {
	// debugger;

	for (let i = 0; i < data.length; i++) {
		let value = data[i];
		data[i] = $makeProxy(value);
	}
}
//--------------------------------------
function walkPlainObject(data) {
	// debugger;
	for (let key in data) {
		// debugger;
		let value = data[key];
		data[key] = $makeProxy(value);
	}
}
//--------------------------------------
// API
function $makeProxy(data) {
	// debugger;
	const $tools = $MB.get('tools');

	if (data == null || typeof(data) != 'object') {
		return data;
	}

	if ($tools.getOb(data) != null) {
		return data;
	}
	//-------------
	let p_data = linkOb(data);

	// debugger;
	if (Array.isArray(data)) {
		walkArray(data);
	} else if ($bb.$isPlainObject(data)) {
		walkPlainObject(data);
	}

	// debugger;
	if (Array.isArray(data)) {
		const arrayProto = $MB.get('getArrayProto')();
		Reflect.setPrototypeOf(data, arrayProto);
	}
	return p_data;
}

//--------------------------------------
export function handle(mb) {
	$MB = mb;
	return $makeProxy;
}
