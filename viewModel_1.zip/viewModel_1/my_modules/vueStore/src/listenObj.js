let $MB;

let $UID = 0;

// 可以被被繼承
class ListenObj {
	$id;
	// 記錄有依賴的數據
	$deps = new Set();
	// 通知 listener 的管道
	$callback;
	$core;
	//-----------------------
	constructor(callback) {
		debugger;

		this.$id = 'l_' + $UID++;
		this.$callback = callback;		
	}
	//-----------------------
	// API
	$dataUpdate() {
		debugger;
		const $jobQueue = $MB.get('jobQueue');
		$jobQueue.add(this);
	}
	//-----------------------
	// API
	$$$dataUpdate() {
		debugger;
		const $api = $MB.get('api');

		// 清除依賴的資訊
		this._clearDepends();
		//-------------
		$api.addListener(this);

		debugger;
		let callback = this.$callback;
		callback();

		$api.removeListener();
	}
	//-----------------------
	$addDeps(deps) {
		// debugger;
		// deps.add(this);
		this.$deps.add(deps);
	}
	//-----------------------
	$removeDeps(deps) {
		// debugger;
		if (this.$deps.has(deps)) {
			deps.delete(this);
			this.$deps.delete(deps);
		}
	}
	//-----------------------
	isEqual(listener) {
		if (!(listener instanceof ListenObj)) {
			return false;
		}
		if (listener.$id != this.$id) {
			return false;
		}
		return true;
	}
	//-----------------------
	_clearDepends() {
		// debugger;
		for (const depList of this.$deps) {
			depList.delete(this);
		}
		this.$deps.clear();
	}
}

export function handle(mb) {
	$MB = mb;
	return ListenObj;
}
