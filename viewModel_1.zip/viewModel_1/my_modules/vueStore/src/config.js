let $MB;

const $config = {
  'ob_attrName': Symbol('observe'),
  'iterate_key': Symbol('iterate_key'),
  'rawData_attr': Symbol('rawData'),
};

export function handle(mb) {
  $MB = mb;
  return $config;
}
