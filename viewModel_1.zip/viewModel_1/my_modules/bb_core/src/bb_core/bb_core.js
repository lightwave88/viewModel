const $bb = {};
//-----------------------
{
	const $globalVars = {};
	$bb.globalVars = function(name, value) {
		let args = Array.from(arguments);
		let length = args.length;

		let res;
		switch (length) {
			case 0:
				res = Object.assign({}, $globalVars);
				break;
			case 1:
				if (name in $globalVars) {
					res = $globalVars[name];
				}
				break;
			case 2:
				if (value == null) {
					delete($globalVars[name])
				} else {
					$globalVars[name] = value;
				}
				break;
			default:
				break;
		} //switch
		return res;
	};
}
//-----------------------
export {
	$bb
};
