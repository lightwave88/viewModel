let $bb;

// 環境資訊
const $ENV = {
	// global
	root: null,
	env: null,
	isWorker: null,
};
////////////////////////////////////////////////////////////////////////////////

const {
	WebEnv,
	NodeJsEnv
} = (function() {

	class interface_Env {
		$Bb;
		constructor() {}
		//-------------------------
		// 共同的操作
		_sameProcess() {
			this._isWorkerEnv();
		}
		//-------------------------
		// 是否是 worker 的運行環境
		_isWorkerEnv() {
			if (typeof(WorkerGlobalScope) != 'undefined') {
				$ENV.isWorker = true;
			} else {
				$ENV.isWorker = false;
			}
		}
	}
	///////////////////////////////////
	class WebEnv extends interface_Env {
		constructor() {
			super();
			let root = (typeof self == 'object' && self.self === self) ? self : null;
			$ENV.root = root;

			this._sameProcess();

			// this._setGlobalVariable();
		}
		//-------------------------
		_setGlobalVariable() {
			// debugger;
			window.$bb = $bb;
		}
	}
	///////////////////////////////////
	class NodeJsEnv extends interface_Env {
		constructor() {
			super($bb);
			let root = (typeof global == 'object' && global.global === global) ? global : null;
			$ENV.root = root;

			this._sameProcess();
		}
	}

	return {
		WebEnv,
		NodeJsEnv
	};
})();
//---------------------------------
function is_nodeJsEnv() {
	// debugger;
	let res = false;

	if (typeof(process) == 'undefined') {
		return res;
	}

	try {
		const checkList = ['chdir', 'cwd', 'exit', 'nextTick'];

		res = checkList.every((obj) => {
			// debugger;
			const type = typeof(process[obj]);
			const r = (type == 'function');
			return r;
		});
	} catch (er) {
		console.log(er);
	}

	return res;
}
//---------------------------------
function is_browserEnv() {
	if (typeof window != 'undefined' && typeof document != 'undefined') {
		return true;
	}
	return false;
}
//---------------------------------
function init() {
	// 執行系統辨認
	// debugger;
	if (is_nodeJsEnv()) {
		$ENV.env = 'nodejs';
		new NodeJsEnv();
	} else if (is_browserEnv()) {
		$ENV.env = 'browser';
		new WebEnv();
	} else {
		$ENV.env = 'unknow';
	}
}

function $handle(bb) {
	$bb = bb;
	init();
	bb.$env = $ENV;
}

export {
	$handle as handle
};
