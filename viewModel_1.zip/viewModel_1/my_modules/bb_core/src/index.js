// debugger;
import {
	$bb
} from './bb_core/index.js';

// basic tools
import {
	handle as h_extends
} from './extends/index.js';
h_extends($bb);

// utils
import {
	handle as h_utils
} from './util/index.js';
h_utils($bb);
//----------------------------
export default $bb;
export {
	$bb
};
