import {
	handle as h_extend
} from './extend.js';

import {
	handle as h_extend_1
} from './extend_1.js';
//---------------------------------
// 對外界面
export function handle(bb) {
	h_extend(bb);

	h_extend_1(bb);
}
