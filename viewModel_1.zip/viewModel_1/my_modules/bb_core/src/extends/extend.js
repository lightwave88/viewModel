let $bb;
const $extend = {};
//--------------------------------------
class TimeoutError extends Error {
	toString() {
		return 'timeoutError';
	}

	toJSON() {
		return 'timeoutError';
	}
}
////////////////////////////////////////////////////////////////////////////////
{
	// tools.getUid(namespace)
	//
	// 取得獨一無二的 id
	const $guid = {
		namespace: {},
		uid: 0,
		getUid(namespace = null) {

			if (namespace == null) {

			} else if (typeof(namespace) == 'string') {
				namespace = namespace.trim();
				namespace = (namespace.length > 0) ? namespace : null;
			} else if (typeof(namespace) == 'symbol') {

			} else {
				throw new TypeError('...');
			}

			if (namespace == null) {
				return this.uid++;
			}
			if (!(namespace in this.namespace)) {
				this.namespace[namespace] = 0;
			}
			return this.namespace[namespace]++;
		}
	};
	// API
	function getUid(namespace) {
		return $guid.getUid(namespace);
	}
	//------------------
	$extend.$getUid = getUid;
	$extend.getUid = getUid;
}
//------------------------------------------------------------------------------
{
	$extend.$isPlainObject = isPlainObject;
	$extend.isPlainObject = isPlainObject;
	//------------------
	const $reg_1 = /^\[object Object\]$/;
	const $proto_toString = Object.prototype.toString;
	const $plainObject = {};
	const $constructor = $plainObject.constructor;
	const $hasOwn = Object.prototype.hasOwnProperty;

	function isPlainObject(data) {
		// debugger;
		let type = typeof(data);

		if (data == null || type != 'object') {
			return false;
		}
		//-------------
		let typeString = $proto_toString.call(data);
		if (!$reg_1.test(typeString)) {
			return false;
		}
		//-------------
		// 比較 instanceObject 與 {} 的差異
		// 比較他們 proto.constructor
		const proto = Object.getPrototypeOf(data);
		if (proto == null) {
			// Object.create(null)
			return true;
		}
		if (!$hasOwn.call(proto, 'constructor')) {
			return false;
		}
		if (proto.constructor !== $constructor) {
			return false;
		}
		return true;
	};
}

//------------------------------------------------------------------------------
{
	$extend.$getClass = getClass;
	$extend.getClass = getClass;
	//------------------
	function getClass(data) {
		// debugger;
		let str_1 = Object.prototype.toString.call(data);
		/*
		let _class = null;
		let res = /\[\w+\s+(\w+)\]/.exec(str_1);
		res = (res == null) ? [] : res;
		([, _class] = res);
    */
		return str_1;
	}
}
//------------------------------------------------------------------------------
{
	$extend.$timeout = timeout;
	$extend.timeout = timeout;

	function timeout(timeLimit, pr) {
		let to = new $TimeOut(timeLimit, pr);
		return to.promise;
	}
	//------------------
	class $TimeOut {
		$def;
		$timeHandle;
		//---------------------------------
		constructor(timeLimit, pr) {

			if (!(pr instanceof Promise)) {
				throw new TypeError('$bb.timeout(,pr) pr not instanceof Promise');
			}
			//---------------
			const def = this.$def = $bb.$deferred();

			// 計時器
			this.$timeHandle = setTimeout(() => {
				// debugger;
				def.reject(new TimeoutError());
				this._clear();
			}, timeLimit);
			//---------------
			pr.then((data) => {
				this._clear();
				def.resolve(data);
			}, (err) => {
				this._clear();
				def.reject(err);
			});
		}
		//---------------------------------
		get promise() {
			return this.$def.promise;
		}
		//---------------------------------
		_clear() {
			clearTimeout(this.$timeHandle);
			this.$timeHandle = null;
		}
	}
}
//------------------------------------------------------------------------------
{
	$extend.$setTimeout = $setTimeout;
	$extend.setTimeout = $setTimeout;
	//------------------
	// 事間到了會 resolve
	// setTimeout(null, time) 類似 sleep(time)
	function $setTimeout(time, fun = null) {
		if (fun != null && typeof(fun) != 'function') {
			throw new TypeError("$bb.detTimeout(, fun), fun must be function");
		}
		const $pr = new Promise(function($res, $rej) {
			setTimeout(() => {
				// debugger;
				let res;
				let er;
				let isFinsh = false;

				if (fun != null) {
					try {
						res = fun();
						isFinsh = true;
					} catch (_er) {
						er = _er;
					}
				} else {
					isFinsh = true;
				}
				//--------
				if (isFinsh) {
					$res(res);
				} else {
					$rej(er);
				}
			}, time);
		});
		return $pr;
	}
}
//------------------------------------------------------------------------------
{
	$extend.$promise = $promise;
	$extend.promise = $promise;
	//------------------
	function $promise(callback, context = null) {
		if (typeof(callback) != "function") {
			throw new TypeError("bb.promise(callback) callback must be function");
		}
		let fun;
		if (context != null) {
			fun = function(...args) {
				return callback.apply(context, args);
			};
		} else {
			fun = callback;
		}
		return new Promise(fun);
	}
}
//------------------------------------------------------------------------------
{
	$extend.$deferred = deferred;
	$extend.deferred = deferred;
	//------------------
	function deferred(timeout) {
		return new Deferred(timeout);
	}

	class Deferred {
		$handle;
		$pr;

		// 'pending', 'rejected', 'fulfilled'
		$state = 'pending';
		//------------------
		constructor(timeout = null) {

			this.$pr = new Promise(($res, $rej) => {
				this.$handle = (function*() {
					// debugger;
					let {
						error,
						data
					} = yield;

					// debugger;
					if (error == null) {
						$res(data);
					} else {
						$rej(error);
					}
				})();
				this.$handle.next();
			});
			//------------------
			// 計時器
			if (typeof timeout == 'number') {
				setTimeout(() => {
					this.$handle.next({
						error: (new TimeoutError()),
						data: null
					});
				}, timeout);
			}
		}
		//------------------------------------------------
		get promise() {
			return this.$pr;
		}
		get state() {
			return this.$state;
		}

		get stateList() {
			return ['pending', 'rejected', 'fulfilled'];
		}
		//------------------------------------------------
		resolve(data) {
			this.$state = 'fulfilled';
			this.$handle.next({
				error: null,
				data
			});
		}
		//------------------------------------------------
		reject(er) {
			this.$state = 'rejected';
			this.$handle.next({
				error: er,
				data: null
			});
		}
	}
}
//------------------------------------------------------------------------------
{
	const $bucket = new Map();

	function $symbol(name) {
		let res;
		if (typeof(name) == 'symbol') {
			for (let [key, vale] of $bucket) {
				if (value === name) {
					res = key;
					break;
				}
			}
		} else if (typeof(name) == 'string') {
			if (!$bucket.has(name)) {
				$bucket.set(name, Symbol(name));
			}
			res = $bucket.get(name);
		}
		return res;
	}
	//------------------
	// 系統內部共享的 symbol
	// tools.symbol(name)
	// 設定取得 symbol
	$extend.$symbol = $symbol;
	$extend.symbol = $symbol;
}
//------------------------------------------------------------------------------
export function handle(bb) {
	$bb = bb;

	for (let name in $extend) {
		if (name in $bb) {
			throw new Error(`${name} has exists`);
		}
		$bb[name] = $extend[name];
	}
	return $extend;
};
