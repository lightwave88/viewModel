// 2024/02/24
export {
	default,
	$bb
} from './src/index.js';
