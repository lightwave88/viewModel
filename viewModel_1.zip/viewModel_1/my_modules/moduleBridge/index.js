// 20240118
export {
	ModuleBridge,
	moduleBridge,
	default,
} from './src/index.js';
