let $UID = 0;
// 用來串聯各個 module
class ModuleBridge {
	$id;
	$parent;
	$childs = new Set();

	// 自己區塊的模組
	$modules = {};
	$fn_onload;
	//-----------------------
	// 以下只能二選一
	$exportList;
	$fn_export;
	//--------------------------------------
	constructor() {
		// debugger;
		this.$id = $UID++;
	}
	//--------------------------------------
	get parent() {
		return this.$parent;
	}
	//--------------------------------------
	set parent(value) {
		if (this.$parent != null) {
			throw new Error('parent has exit');
		}
		this.$parent = value;
	}
	//--------------------------------------
	// 知道有那些 modules
	modules(justSelf = false) {
		let $m = {};
		let root = this;

		while (root != null) {
			Object.assign($m, root.$modules);
			if (justSelf === true) {
				break;
			}
			root = root.$parent || null;
		}
		return $m;
	}
	//--------------------------------------
	// API
	// ({})
	// (name, module)
	import(name, module = null) {
		// debugger;

		if (module == null) {
			if ($isPlainObject(name)) {
				let modules = name;
				name = null;
				for (let moduleName in modules) {
					this.import(moduleName, modules[moduleName]);
				}
			} else {
				throw new Error('...');
			}
		} else {
			if (typeof(name) != 'string') {
				throw new TypeError('...');
			}

			if (name in this.$modules) {
				// 不能有重複的 name
				throw new Error(`module(${name}) has exit`);
			}
			this.$modules[name] = module;
		}
	}
	//--------------------------------------
	// (name, handle)
	// ([name...], handle)
	// ({name:name_1}, handle)
	importHandle(nameMap, handle) {
		// debugger;
		// console.log(`importHandle(${nameMap})`)
		// console.dir(nameMap);
		if (typeof(handle) != 'function') {
			throw new TypeError('...');
		}
		let res = handle.call(this, this);
		let modules = $organizeMaping(nameMap, res);
		this.import(modules);

		let keys = Object.keys(modules);
		return keys;
	}
	//--------------------------------------
	// 取得需要的模組
	get(name) {
		if (typeof(name) != 'string') {
			throw new TypeError('...');
		}
		let res = null;

		let $this = this;
		while ($this != null) {
			if (name in $this.$modules) {
				res = $this.$modules[name];
				break;
			}
			$this = $this.$parent;
		}
		if (res == null) {
			throw new Error(`no this module(${name})`);
		}
		return res;
	}
	//--------------------------------------
	// API
	has(name, justSelf = false) {
		if (typeof(name) != 'string') {
			throw new TypeError('...');
		}
		if (typeof(justSelf) != 'boolean') {
			throw new TypeError('...');
		}
		// ------------
		let $this = this;
		while ($this != null) {
			if (name in $this.$modules) {
				return true;
			}
			if (justSelf) {
				break;
			}
			$this = $this.$parent;
		}
		return false;
	}
	//--------------------------------------
	// 對外輸出模組
	// arg: function
	// arg: [...]<string>
	// arg: '*'(匯出所有)
	// arg: string(匯出指定單一)
	export (arg) {
		// debugger;
		if (typeof(arg) == 'function') {
			this.$fn_export = arg;
		} else if (Array.isArray(arg)) {
			// 要匯出的列表
			this.$exportList = arg;
		} else if (typeof(arg) == 'string') {

			arg = arg.trim();
			switch (key) {
				case '*':
					// 匯出所有
					this.$exportList = Object.keys(this.modules);
					break;
				default:
					// 匯出指定
					this.$exportList = [arg];
					break;
			}
		} else {
			throw new TypeError('...');
		}
	}
	//--------------------------------------
	// 傳統用法
	linkParent(parent) {
		// debugger;
		if (!(parent instanceof ModuleBridge)) {
			throw new Error('.....');
		}
		child.parent = parent;
		parent.$childs.add(child);
	}
	//--------------------------------------
	// ({...}, modules = {})
	// ([...]<string>, modules = {})
	// (string, module)
	// ('*', modules = {})
	importModule(nameMap, child) {
		// debugger;

		if (!(child instanceof ModuleBridge)) {
			throw new Error('.....');
		}
		if (nameMap != null) {
			(() => {
				if (typeof(nameMap) == 'string') {
					return;
				}
				if ($isPlainObject(nameMap)) {
					return;
				}
				if (Array.isArray(nameMap)) {
					return;
				}
				throw new Error('...');
			})();
		}
		//-------------
		if (child.parent != null) {
			throw new Error('...');
		}
		if (this.$childs.has(child)) {
			throw new Error('...');
		}
		child.parent = this;
		this.$childs.add(child);
		//-------------
		let moduleMap;
		if (child.$fn_export != null) {
			// 設定輸出是 callback
			let fn = child.$fn_export;
			child.$fn_export = undefined;

			let modules = fn.call(child, child);
			moduleMap = $organizeMaping(nameMap, modules);

		} else if (Array.isArray(child.$exportList)) {
			// 設定輸出是 []
			let exportMap = {};

			while (child.$exportList.length > 0) {
				let name = child.$exportList.pop();
				name = name.trim();
				if (child.$modules[name] == null) {
					throw new Error('...');
				}
				exportMap[name] = child.$modules[name];
			}
			child.$exportList = undedined;
			moduleMap = $organizeMaping(nameMap, exportMap);
		}
		//-------------
		this.import(moduleMap);

		let keys = Object.keys(moduleMap);
		return keys;
	}
	//--------------------------------------
	// 當 root 都 import 完
	// 會執行的 callback
	onload(callback) {
		// debugger;
		if (typeof(callback)) {
			throw new TypeError('...');
		}
		$fn_onload = callback;
	}
	//--------------------------------------
	finish() {
		// debugger;
		if (this.$parent == null) {
			// debugger;
			this.$onloaded();
		} else {
			throw new Error('...');
		}
	}
	//--------------------------------------
	$onloaded() {
		// debugger;
		// 由最下層開始

		let $checkList = [this];
		for (let i = 0; $checkList[i] != null; i++) {
			let mb = $checkList[i];

			if (mb.$fn_onload != null) {
				let fn = mb.$fn_onload;
				mb.$fn_onload = undefined;
				fn.call(mb, mb);
			}
			for (let child of mb.$childs) {
				this.$childs.delete(child);
				$checkList.push(child);
			}
			mb.$childs = undefined;
		}
	}
}
const moduleBridge = new ModuleBridge();

////////////////////////////////////////
// name: string|'*'|[]|{}
// 處理名稱配對
function $organizeMaping(nameMap, modules) {
	// debugger;

	let $moduleMap = {};

	if (typeof(nameMap) == 'string') {
		// export 只有單個模組
		nameMap = nameMap.trim();

		switch (nameMap) {
			case '*':
				// 匯入所有
				if (!$isPlainObject(modules)) {
					throw new TypeError('.....');
				}
				Object.assign($moduleMap, modules);
				break;
			default:
				$moduleMap[nameMap] = modules;
				break;
		}
	} else if (Array.isArray(nameMap)) {

		if (!$isPlainObject(modules)) {
			throw new TypeError('...');
		}
		while (nameMap.length > 0) {
			let name = nameMap.shift();
			name = name.trim();
			if (modules[name] == null) {
				throw new Error(`no this (${name}) export`);
			} else {
				$moduleMap[name] = modules[name];
			}
		}

	} else if ($isPlainObject(nameMap)) {

		if (!$isPlainObject(modules)) {
			throw new TypeError('...');
		}
		for (let key in nameMap) {
			if (modules[key] == null) {
				throw new Error(`no this (${key}) export`);
			}
			// 改名
			let newName = nameMap[key];
			// null, undefined, ''
			if (newName == null || newName === '') {
				// 沿用原本名
				newName = key;
			}
			$moduleMap[newName] = modules[key];
		}
	} else {
		throw new Error('.....');
	}
	return $moduleMap;
}
//-----------------------

const $isPlainObject = (() => {
	const $reg_1 = /^\[object Object\]$/;
	const $proto_toString = Object.prototype.toString;
	const $plainObject = {};
	const $constructor = $plainObject.constructor;
	const $hasOwn = Object.prototype.hasOwnProperty;

	return function(data) {
		let type = typeof(data);

		if (data == null || type != 'object') {
			return false;
		}
		//-------------
		try {
			let typeString = $proto_toString.call(data);
			if (!$reg_1.test(typeString)) {
				return false;
			}
		} catch (e) {
			debugger;
		}
		//-------------
		// 比較 instanceObject 與 {} 的差異
		// 比較他們 proto.constructor
		const proto = Object.getPrototypeOf(data);
		if (proto == null) {
			// Object.create(null)
			return true;
		}
		if (!$hasOwn.call(proto, 'constructor')) {
			return false;
		}
		if (proto.constructor !== $constructor) {
			return false;
		}
		return true;
	}
})();
//--------------------------------------
export {
	ModuleBridge,
	moduleBridge
};

export default ModuleBridge;
