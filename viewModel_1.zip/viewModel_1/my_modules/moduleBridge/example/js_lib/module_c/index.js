import {
  ModuleBridge
} from '../moduleBridge.js';

const $MB = new ModuleBridge();
//-----------------------
import {
  handle as h_a
} from './a.js';

const $a = h_a($MB);
$MB.import('a', $a);
//-----------------------
import {
  handle as h_b
} from './b/index.js';

const $b = h_b($MB);
$MB.import('b', $b);
//-----------------------
// 對外輸出

function handle(outsideMoudule) {

  // 引入外部 outsideMoudule
  $MB.import('outside', outsideMoudule);
  $MB.finish();

  return {
    a: $a,
    b: $b
  };
}

export {
  handle
};