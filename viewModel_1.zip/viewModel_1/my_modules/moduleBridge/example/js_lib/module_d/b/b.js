debugger;

let $MB;

const $b = {
  name: 'b',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    console.dir($MB.modules());
  }
};
//------------------
function loaded() {
  debugger;
  console.log('b...');
  console.dir(this.modules());
  console.log('-----------');
}
//------------------
function handle(mb) {
  debugger;
  $MB = mb;
  mb.onload(loaded);
  return $b;
}

export {
  handle
};
