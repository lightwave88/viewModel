debugger;

import {
  ModuleBridge
} from '../../moduleBridge.js';
const $MB = new ModuleBridge(true);
//-----------------------
import {
  handle as h_b
} from './b.js';

// 對外輸出 b
$MB.importHandle('b', h_b);
//-----------------------
import {
  handle as h_c
} from './c.js';

// c 只在此區塊可以看到
$MB.importHandle('c', h_c);
//-----------------------

// 注意此處
// 對外輸出
$MB.export(function (mb) {
	debugger;
	
	const $b = this.get('b');	
  return $b;
});

export default $MB;