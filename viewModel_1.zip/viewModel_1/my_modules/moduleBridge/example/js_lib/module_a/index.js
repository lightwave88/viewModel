import {
  ModuleBridge
} from '../moduleBridge.js';

const $MB = new ModuleBridge();
//-----------------------
import {
  handle as h_a
} from './a.js';

const $a = h_a($MB);
$MB.import('a', $a);
//-----------------------
import {
  handle as h_b
} from './b/index.js';

const $b = h_b($MB);
$MB.import('b', $b);

// 可以不用 
$MB.finish();
//-----------------------
// 對外輸出
export default {
  a: $a,
  b: $b
};