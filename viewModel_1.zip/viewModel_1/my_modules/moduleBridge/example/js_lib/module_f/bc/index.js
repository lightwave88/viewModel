import {
	ModuleBridge
} from '../../moduleBridge.js';
const $MB = new ModuleBridge();
//------------------
import m_b from './b/index.js';
$MB.import('b', m_b);
//------------------
import {
	handle as h_c
} from './c/index.js';
$MB.importHandle('c', h_c);
//------------------
$MB.export(function(mb) {
	debugger;
	const b = mb.get('b');
	const c = mb.get('c');

	return {
		b,
		c
	}
});

export default $MB;
