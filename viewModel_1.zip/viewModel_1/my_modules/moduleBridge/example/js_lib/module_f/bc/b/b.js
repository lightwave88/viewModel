debugger;

let $MB;

const $b = {
	name: 'b',
	aboutMe() {
		debugger;
		console.log(this.name);

		this.getModules();
	},
	getModules() {
		debugger;
		console.dir($MB.modules());
	}
};
//-------------
function onload() {
  console.log('b...')
  console.dir(this.modules());
  console.log('----------');
}
//-------------
function handle(mb) {
	debugger;
	$MB = mb;
	this.onload(onload);
	return $b;
}

export {
	handle
};
