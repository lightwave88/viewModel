debugger;

let $MB;

const $c = {
  name: 'c',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    console.dir($MB.modules());	
  }
};

function handle(mb) {
  debugger;
  $MB = mb;	
  return $c;
}

export {
  handle
};