import MB from '../../mb.js';
const $MB = new MB();

const $tools = {};
//-----------------------
import {
	handle as h_extend_1
} from './extend_1.js';
Object.assign($tools, h_extend_1($MB));
//-----------------------
import {
	handle as h_extend_2
} from './extend_2.js';
Object.assign($tools, h_extend_2($MB));
//-----------------------
$MB.export(function () {
	return $tools;
});

export default $MB;
