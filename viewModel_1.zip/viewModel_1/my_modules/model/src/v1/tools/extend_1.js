let $MB;
const $extend = {};

// 複製 data 的值
$extend.copyValue = function(data) {
	let copy = JSON.parse(JSON.stringify(data))
	return copy;
};

//--------------------------------------

// 對比兩數據值是否相同
$extend.isEqualValue = function(oldData, newData) {
	const $config = $MB.get('config')
	const needCompareValue = $config.isNeedCompareValue

	if (!needCompareValue) {
		// 不用比較值
		// 凡是有 set value 都算是有改變
		return false;
	}
	//-------------
	let type_a = typeof(oldData);
	let type_b = typeof(newData);

	let compareValue;

	if (type_a != type_b) {
		compareValue = false;
	} else {

		// 針對子串比對
		switch (type_a) {
			case 'string':
				if (oldData.length != newData.length) {
					compareValue = false;
				} else {
					// localeCompare 會非常緩慢
					compareValue = (oldData == newData);
				}
				break;
			case 'number':
				compareValue = (oldData == newData);
			default:
				compareValue = (oldData === newData);
				break;
		}
	}
	return compareValue;
};
//--------------------------------------
/*
 $extend.getDataKeys = function (data) {
 const $bb = $MB.get('bb');
 let _class = this.$getClass(data);

 let keys;

 switch (_class) {
 case '[object Object]':
 keys = Object.keys(data);
 break;
 case '[object Array]':
 data.forEach((item, i) => {
 keys.push(i);
 });
 break;
 case '[object Map]':
 keys = Array.from(data.keys());
 break;
 case '[object Set]':
 default:
 break;
 }

 if (!Array.isArray(keys)) {
 throw new TypeError('unSupport data type');
 }
 return keys;
 };
 */
//--------------------------------------
$extend.getObserver = function(data) {
	// debugger;

	// 儘量取 rawData 避免透過 proxy 讀取激發不需要的反應
	data = this.getRawData(data);

	if (data == null || typeof(data) != 'object') {
		return undefined;
	}
	//-------------
	const $config = $MB.get('config');
	let key = $config['ob_attrName'];
	key = this.symbol(key);

	let res = (data[key] != null) ? data[key] : undefined;
	return res;
};
//--------------------------------------
// 取得 proxy 原始的 data
$extend.getRawData = function(data) {
	// debugger;
	if (data == null || typeof(data) != 'object') {
		return data;
	}
	const $config = $MB.get('config');
	let key = $config['rawData_attrName'];
	key = this.symbol(key);

	let rawData = (data[key] != null) ? data[key] : data;
	return rawData;
};
//--------------------------------------
$extend.hasObserver = function(data) {
	let res = this.getObserver(data);
	res = (res != null)
	return res;
};
//--------------------------------------
// 在數據後面植入 ob
$extend.dataLinkOb = function(data, ob) {
	const $config = $MB.get('config');
	let ob_attrName = $config['ob_attrName'];
	ob_attrName = this.symbol(ob_attrName);

	Object.defineProperty(data, ob_attrName, {
		value: ob,
		// 不可表達式賦值
		writable: false,
		// 是否能刪除
		configurable: true,
		// 是否能列舉
		enumerable: false,
	});
};
//--------------------------------------
// data 去除 ob
$extend.dataUnLinkOb = function(data) {

	let rawData = this.getRawData(data);
	if (rawData == null || typeof(rawData) != 'object') {
		return;
	}
	const $config = $MB.get('config');
	let key = $config['ob_attrName'];
	key = this.symbol(key);

	if (key in rawData) {
		delete(rawData[key]);
	}
}
//--------------------------------------
// 特殊工具
$extend.symbol = (() => {
	const $bucket = new Map();

	function fn_symbol(name) {
		let res = null;
		if (typeof(name) == 'symbol') {
			for (let [str, sym] of $bucket) {
				if (sym == name) {
					res = str;
					break;
				}
			}
		} else if (typeof(name) == 'string') {
			if (!$bucket.has(name)) {
				$bucket.set(name, Symbol(name));
			}
			res = $bucket.get(name);
		}
		return res;
	};
	//--------
	return fn_symbol;
})();
//--------------------------------------
// 判斷 key 是否是要讀取 rawData

// 判斷 key 是否是爲了取得 rawData
$extend.isGetRawdata = function(key) {
	let type = typeof(key);
	if (type != 'symbol') {
		return false;
	}
	const $config = $MB.get('config');
	let s_key = $config['rawData_attrName'];
	s_key = this.symbol(s_key);

	return (key == s_key);
};
//--------------------------------------
// 判斷 key 是否是爲了取得 observer
$extend.isGetObserver = function(key) {
	// debugger;
	if (typeof(key) != 'symbol') {
		return false;
	}
	const $config = $MB.get('config');
	let s_key = $config['ob_attrName'];
	s_key = this.symbol(s_key);

	return (key === s_key);
};
//--------------------------------------
// for test
$extend.toString = function(value) {
	let isOk = false;
	let res;
	try {
		isOk = true;
		res = value.toString();
	} catch (e) {}
	if (isOk) {
		return res;
	}
	//-------------
	try {
		isOk = true;
		res = value.valueOf();
	} catch (e) {}
	if (isOk) {
		return res;
	}
	//-------------
	res = ('' + value);
	return res;
};
//--------------------------------------
// 正規化 path
$extend.regulePath = (() => {

	// 取得[...]內的內容
	const $reg_1 = /\[(.+?)\]/;

	// 取得"..."內的內容
	const $reg_2 = /(['"])(?:.+?)\1/;
	const $reg_3 = /^\./;

	return function(path) {
		// debugger;

		let $res = {
			path: '',
			pathList: []
		};

		if (path == null) {
			return $res;
		} else if (typeof(path) == 'string') {
			path = path.trim();
			if (path.length == 0 || path == '.') {
				return $res;
			}
		} else {
			throw new TypeError('...');
		}
		//-------------
		let reg_1 = RegExp($reg_1, 'g');

		path = path.replace(reg_1, (m, g1) => {
			// debugger;

			let word = g1;
			word = word.replace($reg_2, (m, g1, g2) => {
				// debugger;
				return g2;
			});
			return ('.' + word);
		});
		// debugger;
		path = path.replace($reg_3, '');

		$res.path = path;
		$res.pathList = path.split('.');

		return $res;
	};
})();
//--------------------------------------
$extend.getClass = function(data) {
	return Object.prototype.toString.call(data);
};
//--------------------------------------

// 可以取得 data 但不驚擾 proxy
$extend.getDataByPath = (() => {

	const $reg_1 = /^\s{1,}$/;

	function getDataByPath(data, path, keepSilence = false) {
		debugger;
		const $tools = $MB.get('tools');

		if (path == null) {
			path = '';
		}

		let pathList;
		if (typeof(path) == 'string') {
			path = ($tools.regulePath(path)).path;
			if (path.length == 0) {
				pathList = [];
			} else {
				pathList = path.split('.');
			}
		} else if (Array.isArray(path)) {
			pathList = path;
		} else {
			throw new TypeError('...');
		}
		//--------
		let res;
		let ob = $tools.getObserver(data);
		if (ob != null && keepSilence) {

			let silentValue = ob.getSilence();
			ob.silence(true);

			// 讀取
			res = getData(data, pathList);

			ob.silence(silentValue);
		} else {
			res = getData(data, pathList);
		}
		return res;
	};
	//-----------------------
	function getData(data, pathList) {
		// debugger;

		const $tools = $MB.get('tools');
		//-------------
		while (pathList.length > 0) {
			// debugger;
			if (typeof(data) != 'object' || data == null) {
				break;
			}
			let key = pathList.shift();
			if ($reg_1.test(key)) {
				// 錯誤格式
				throw new Error('...');
			}
			//-------------
			// get data class
			let rawData = $tools.getRawData(data);
			let _class = $tools.getClass(rawData);
			//-------------
			// debugger;
			switch (_class) {
				case '[object Object]':
					data = data[key];
					break;
				case '[object Array]':
					key = parseInt(key, 10);
					data = data[key];
					break;
				default:
					data = undefined;
					break;
			} // switch
			//------------------
		} // while
		return data;
	}

	return getDataByPath;
})();
//--------------------------------------
{
	$extend.cloneReactData = function(data) {
		// 未
		// 未
		// 未
		// 未
		return;
	}

	const $cloneData = {
		clone(data) {

			let loopList = [];
		},
		//------------------
		_isContainer(data) {
			let res = false;
			if (Array.isArray(data)) {
				res = 'array';
			} else {
				const $tools = $MB.get('tools');
				if ($tools.isPlainObject(data)) {
					res = 'plainObj';
				}
			}
			return res;
		},
		//------------------
		_getItem(data, parent = null) {

			let type = this._isContainer(data);
			return {
				type,
				parent,
				data,
			}
		},
		//------------------
	};
}
//--------------------------------------
$extend.isPlainObject = (() => {

	const $reg_1 = /^\[object Object\]$/;
	const $proto_toString = Object.prototype.toString;
	const $plainObject = {};
	const $constructor = $plainObject.constructor;
	const $hasOwn = Object.prototype.hasOwnProperty;
	//--------
	function isPlainObject(data) {
		// debugger;
		let type = typeof(data);

		if (data == null || type != 'object') {
			return false;
		}
		//-------------
		let typeString = $proto_toString.call(data);
		if (!$reg_1.test(typeString)) {
			return false;
		}
		//-------------
		// 比較 instanceObject 與 {} 的差異
		// 比較他們 proto.constructor
		const proto = Object.getPrototypeOf(data);
		if (proto == null) {
			// Object.create(null)
			return true;
		}
		if (!$hasOwn.call(proto, 'constructor')) {
			return false;
		}
		if (proto.constructor !== $constructor) {
			return false;
		}
		return true;
	};
	//--------
	return isPlainObject;
})();
//--------------------------------------
export function handle(mb) {
	$MB = mb;
	return $extend;
}