let $MB;
const $extend = {};

// $extend.deepMatch
(() => {

  const $matchArray = (() => {

    class ArrayMatch {
      $oldData;
      $newData;
      $hasMatchIndex;
      $indexName;
      //------------------
      constructor(oldData, newData) {
        const $tools = $MB.get('tools');
        const $config = $MB.get('config');

        let ob = $tools.getObserver(oldData);
        if (ob == null) {
          throw new TypeError('...');
        }
        ob = $tools.getObserver(newData);
        if (ob != null) {
          throw new TypeError('...');
        }
        //--------
        this.$oldData = oldData;
        this.$newData = newData;
        this.$hasMatchIndex = new Set();
        this.$indexName = $config['indexName'];
      }
      //------------------
      main() {
        // debugger;
        this._start();

        let list = this._end();

        return list;
      }
      //------------------
      _start() {
        // debugger;

        const $tools = $MB.get('tools');

        let $length = Math.max(this.$newData.length, this.$oldData.length);

        // 找尋可適配的 oldData
        for (let i = 0; i < $length; i++) {
          // debugger;

          if (i >= this.$newData.length) {
            // 若 oldData 比較長
            while (this.$oldData.length > this.$newData.length) {
              this.$oldData.pop();
            }
            break;
          }
          //-------------
          if (this.$hasMatchIndex.has(i)) {
            continue;
          }
          //-------------
          let new_d = this.$newData[i];

          let needMatch = ($tools.isPlainObject(new_d) && (this.$indexName in new_d));
          if (needMatch) {
            // 移動 oldData 以適配 new_d
            this._search_oldData(i, new_d);
          }
          this.$hasMatchIndex.add(i);
        } // for
      }
      //------------------
      _search_oldData(index, newItem) {
        // debugger;

        const $indexName = this.$indexName;
        const $tools = $MB.get('tools');

        let new_id = newItem[$indexName];
        let find = false;
        let needSearchItem;

        for (let i = 0; i < this.$oldData.length; i++) {
          // debugger;

          if (this.$hasMatchIndex.has(i)) {
            continue;
          }
          let old_d = this.$oldData[i];

          let needMatch = ($tools.isPlainObject(old_d) && (this.$indexName in old_d));

          if (!needMatch) {
            // 不合規格
            continue;
          } else {
            let old_id = old_d[$indexName];

            if (old_id != new_id) {
              continue;
            } else {
              // find

              find = true;
              // this.$hasMatchIndex.add(index);

              if (i == index) {
                continue;
              } else {

                needSearchItem = this.$oldData[index];

                // 只是交換位置，避免被移除
                let ob = $tools.getObserver(needSearchItem);
                ob.switchingPos();

                ob = $tools.getObserver(old_d);
                ob.switchingPos();

                // debugger;
                this.$oldData[i] = null;
                // debugger;
                this.$oldData[index] = old_d;
              }
              break;
            }
          }
        } // for
        //-------------
        // 記錄處理過的 index
        this.$hasMatchIndex.add(index);
        // debugger;

        if (!find) {

          let oldData = this.$oldData[index];
          let canMatch = ($tools.isPlainObject(oldData) && (this.$indexName in oldData));

          if (canMatch) {
            let ob = $tools.getObserver(oldData);
            ob.switchingPos();

            // debugger;
            this.$oldData[index] = null;

            this._search_newData(oldData);
          } else {
            // debugger;
            this.$oldData[index] = null;
          }

        } else {
          if (needSearchItem != null) {
            this._search_newData(needSearchItem);
          }
        }
      }
      //------------------
      _search_newData(oldData) {
        // debugger;
        const $tools = $MB.get('tools');
        const $indexName = this.$indexName;

        let old_id = oldData[$indexName];

        let find = false;
        let needSearchItem;

        for (let i = 0; i < this.$newData.length; i++) {
          // debugger;
          if (this.$hasMatchIndex.has(i)) {
            continue;
          }
          let new_d = this.$newData[i];

          let canMatch = ($tools.isPlainObject(new_d) && (this.$indexName in new_d));

          if (!canMatch) {
            continue;
          } else {
            let id = new_d[this.$indexName];
            if (old_id != id) {
              continue;
            } else {
              // find

              find = true;
              this.$hasMatchIndex.add(i);
              //-------------
              // 要移開
              needSearchItem = this.$oldData[i];

              let ob = $tools.getObserver(needSearchItem);
              if (ob != null) {
                ob.switchingPos();
              }
              //-------------
              // 插入 match 的數值
              this.$oldData[i] = oldData;
              break;
            }
          }
        } // for
        //-------------
        if (find) {
          let canMatch = ($tools.isPlainObject(needSearchItem) && ($indexName in needSearchItem));
          if (canMatch) {
            this._search_newData(needSearchItem);
          } else {
            let ob = $tools.getObserver(needSearchItem);
            if (ob != null) {
              ob.remove();
            }
          }
        } else {
          let ob = $tools.getObserver(oldData);
          ob.remove();
        }
      }
      //------------------
      _end() {
        // debugger;
        let list = [];

        // 數據配對
        for (let i = 0; i < this.$newData.length; i++) {
          let newData = this.$newData[i];
          let oldData = this.$oldData[i];
          list.push({
            newData,
            oldData
          });
        }
        return list;
      }
    }
    //------------------
    return function(oldData, newData) {
      // debugger;
      let obj = new ArrayMatch(oldData, newData);
      let matchList = obj.main();
      return matchList;
    };
  })();
  ///////////////////////////////////
  const $matchPlainObj = (() => {
    return function matchPlainObj(oldData, newData) {
      // debugger;

      let oldKeys = Object.keys(oldData);
      let newKeys = Object.keys(newData);

      let intersectionKeys = new Set();

      oldKeys.forEach((key) => {
        // debugger;
        if (!newKeys.includes(key)) {
          delete(oldData[key]);
        } else {
          intersectionKeys.add(key);
        }
      });
      newKeys.forEach((key) => {
        // debugger;
        if (!oldKeys.includes(key)) {
          oldData[key] = newData[key];
        } else {
          intersectionKeys.add(key);
        }
      });

      // 返回有交集的 key
      let keys = Array.from(intersectionKeys);

      // debugger;
      return keys;
    }
  })();
  ///////////////////////////////////
  $extend.deepMatch = (() => {

    class DeepMatch {
      $loopList = [];
      $indexName;
      //------------------
      constructor(oldData, newData) {
        // debugger;

        const $bb = $MB.get('bb');
        const $tools = $MB.get('tools');
        const $config = $MB.get('config');

        this.$indexName = $config['indexName'];

        if (!$tools.hasObserver(oldData)) {
          throw new TypeError('...');
        }

        let type_1 = $bb.$getClass(oldData);
        let type_2 = $bb.$getClass(newData);

        if (type_1 != type_2) {
          throw new TypeError('differet type');
        }

        if (!Array.isArray(newData) && !$tools.isPlainObject(newData)) {
          throw new TypeError('...');
        }

        this.$loopList.push({
          oldData,
          newData
        });
      }
      //------------------
      main() {
        // debugger;

        const $bb = $MB.get('bb');
        const $tools = $MB.get('tools');
        const $indexName = this.$indexName;

        let matchList = this.$loopList;

        for (let i = 0; matchList[i] != null; i++) {
          // debugger;

          // oldData, newData 是同 type
          // 且一定是容器
          let {
            oldData,
            newData
          } = matchList[i];

          if (Array.isArray(newData)) {
            // loop child

            // 主旨，儘量重用舊 data
            const parent = oldData;

            // debugger;
            console.dir(oldData);
            console.dir(newData);

            // 作出排序對應
            let list = $matchArray(oldData, newData);
            // debugger;
            console.dir(list);

            // 已經排序配對過
            for (let j = 0; j < list.length; j++) {
              // debugger;

              let {
                oldData: old_child,
                newData: new_child
              } = list[j];

              let type_1 = $bb.$getClass(old_child);
              let type_2 = $bb.$getClass(new_child);

              if (type_1 != type_2) {
                parent[j] = new_child;
              } else {
                switch (type_1) {
                  case '[object Object]':

                    // 是否是映射的數據
                    if ($indexName in old_child && $indexName in new_child) {
                      if (old_child[$indexName] == new_child[$indexName]) {
                        matchList.push({
                          oldData: old_child,
                          newData: new_child,
                        });
                        break;
                      }
                    }
                    parent[j] = new_child;
                    break;
                  case '[object Array]':
                    matchList.push({
                      oldData: old_child,
                      newData: new_child,
                    });
                    break;
                  default:
                    parent[j] = new_child;
                    break;
                } // switch
              }
            }

          } else if ($tools.isPlainObject(newData)) {
            // debugger;

            // loop child

            const parent = oldData;

            // 配對數據
            // debugger;
            console.dir(oldData);
            console.dir(newData);

            let keys = $matchPlainObj(oldData, newData);

            // debugger;
            console.dir(oldData);
            console.dir(newData);

            while (keys.length > 0) {
              let key = keys.shift();

              if (key == this.$indexName) {
                // 不必比對
                continue;
              }

              let old_child = oldData[key];
              let new_child = newData[key];

              let type_1 = $bb.$getClass(old_child);
              let type_2 = $bb.$getClass(new_child);

              if (type_1 != type_2) {
                parent[key] = new_child;
              } else {
                switch (type_1) {
                  case '[object Object]':
                  case '[object Array]':
                    // 不直接指派
                    matchList.push({
                      oldData: old_child,
                      newData: new_child,
                    });
                    break;
                  default:
                    parent[key] = new_child;
                    break;
                } // switch
              }
            } // while
          }
        } // for
      }
    } // class
    //------------------
    return function(oldData, newData) {
      let match = new DeepMatch(oldData, newData);
      match.main();
    };
  })();
})();
//-----------------------
export function handle(mb) {
  //  debugger;
  $MB = mb;
  return $extend;
}
