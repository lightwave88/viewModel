let $MB;

let config = {
  // 物件取得 observer 的屬性名稱
  'ob_attrName': 'bb_observe',

  // proxy 取得 rawData 的 key
  'rawData_attrName': 'rawData',

  // dataUpdate 默認的 index name
  'indexName': '$index',

  // set data 是否要比對資料值
  'isNeedCompareValue': true,
};
//------------------
const $config = new Proxy(config, {
  get(target, key) {
    if(!(key in target)){
      throw new Error(`no this attr ${key}`);
    }
    return target[key];
  },
  set(target, key, value) {
    if(!(key in target)){
      throw new Error(`no this attr ${key}`);
    }
    target[key] = value;
    return true;
  },
  deleteProperty(target, key) {
    return false;
  }
});


export function handle(mb) {
  $MB = mb;
  return $config;
}
