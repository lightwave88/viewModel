let $MB;
let $UID = 0;

/*
	Model 是爲了方便操作 observerData
*/
class Model {
	$$$id;

	// 所屬的 ob
	$$$observer;

	$$$listeners = new Set();
	//---------------------------------
	constructor(data = {}) {
		// debugger;
		const $tools = $MB.get('tools');
		const $react = $MB.get('react');

		this.$$$id = 'model_' + $UID++;

		let jug_1 = !Array.isArray(data);
		let jug_2 = !$tools.isPlainObject(data)

		if (jug_1 && jug_2) {
			throw new TypeError('...');
		}

		let ob = $tools.getObserver(data);
		if (ob == null) {
			// 採用 data 複本
			let {
				ob: _ob
			} = $react.createOb(data, true);
			ob = _ob;
		}
		this.$$$observer = ob;

		// 傾聽 observe
		ob.addModel(this);
	}
	//---------------------------------
	static create(data = {}) {
		if (data instanceof Model) {
			return data;
		}
		let model = new Model(data);
		return model;
	}
	//---------------------------------
	get data() {
		return this.$$$observer.data;
	}

	// 取得上層 data 的方式
	get rootData() {
		let rootOb = this.$$$observer.root;
		return rootOb.data;
	}

	get observer() {
		return this.$$$observer;
	}

	get class() {
		return Model;
	}
	//---------------------------------
	// API
	// args = {context, update, updated, remove}
	effect(args = {}) {
		debugger;

		const Listener = $MB.get('MListener');
		const listener = Listener.create(this, args);

		// 登錄 listener
		this.$$$listeners.add(listener);
		//------------------
		return ((handle = null) => {
			// debugger;
			if (listener.isInited) {
				return;
			}
			try {
				listener.dataChanged(handle);
			} catch (e) {
				console.dir(e);
				throw e;
			}
			return listener;
		});
	}
	//---------------------------------
	// data 變動不會被記錄
	silence(isSilence) {
		/*
		let ob = this.observer;
		return ob.silence(isSilence);
     * 
     */
	}
	//---------------------------------
	// for test
	// 手動加入變動的 path
	addChange(path) {
		debugger;
		const $tools = $MB.get('tools');

		let selfOb = this.$$$observer;
		let data = selfOb.data;
		data = $tools.getDataByPath(data, path, true);
		let ob = $tools.getObserver(data);
		selfOb.addChange(ob, key);
	}
	//---------------------------------
	// 針對一堆物品作資料更新
	updateData(path, newData) {
		debugger;
		const $tools = $MB.get('tools');

		let oldData = $tools.getDataByPath(this.data, path, true);
		debugger;
		$tools.deepMatch(oldData, newData);
	}
	//---------------------------------
	// API
	commit(args = null) {
		// debugger;
		let pr = this.$$$observer.commit(args);
		return pr;
	}
	//---------------------------------
	// 是否在 commit 過程
	isOnCommit() {
		let res = this.$$$observer.isOnCommit_forModel();
		return res;
	}
	//---------------------------------
	toJSON() {
		return this.$$$observer.data;
	}
	//---------------------------------
	isEqaul(model) {
		if (!(model instanceof Model)) {
			return false;
		}
		return (this.$$$id == model.$$$id);
	}
	//---------------------------------
	// 取得資料卻不會驚動 proxy
	getRawData() {
		let data = this.$$$observer.rawData;;
		return data;
	}
	//---------------------------------
	getObserver() {
		return this.$$$observer;
	}
	//---------------------------------
	cloneData() {

	}
	//---------------------------------
	// for test
	getDeps(isPlainObject = false) {
		let data = this.$$$observer.getDeps(isPlainObject);
		if (isPlainObject) {
			data = JSON.stringify(data);
		}
		return data;
	}
	//---------------------------------
	// callback
	// observe 呼叫
	$_dataChanged(changeList, handle) {
		// debugger;

		// model
		// model
		// model
		// const ob = this.$$$observer;

		for (let listener of this.$$$listeners) {
			debugger;
			if (!listener.isMatch(changeList)) {
				debugger;
				continue;
			}
			//--------
			debugger;

			// 執行 listener 主要任務
			// 內部會判斷是否 double 執行
			try {
				listener.dataChanged(handle);
			} catch (e) {
				console.dir(e);
				throw e;
			}
		} // for
	}
	//---------------------------------
	// callback
	// 當 model 所屬的 observe 被移除
	$_remove() {
		debugger;
		for (let listener of this.$$$listeners) {
			this.$$$listeners.delete(listener);
			listener.remove();
		}
		this.$_destroy();
	}
	//---------------------------------
	$_destroy() {
		debugger;
		let names = Object.getOwnPropertyNames(this);
		while (names.length > 0) {
			let name = names.pop();
			this[name] = undefined;
			delete(this[name]);
		}
	}
} // class
//////////////////////////////

export function handle(mb) {
	$MB = mb;
	return Model;
}