let $MB;
let $UID = 0;
//////////////////////////////
class Model_listener {
	$id;
	$context;

	// 隸屬的 model
	$model;
	//-------------
	$callbacks = {
		update: undefined,
		remove: undefined,
	}
	//-------------
	// this.$fn_update 是否經過第一次執行
	$isInited = false;

	// 依賴的數據
	// ob => paths
	$depList = new Map();

	$propChange = false;
	//----------------------------
	static create(model, args) {
		let listener = new Model_listener(model, args);
		return listener;
	}
	//----------------------------
	constructor(model, args = {}) {
		// debugger;

		this.$id = 'listener_' + $UID++;
		this.$model = model;

		let {
			context = null,
		} = args;
		//-------------
		this.$context = (context != null) ? context : window;

		// callback
		for (let key in this.$callbacks) {
			if (!(key in args)) {
				continue;
			}
			let fun = args[key];
			if (typeof(fun) == 'string') {
				fun = this.$context[fun];
			}
			if (typeof(fun) != 'function') {
				throw new TypeError('...');
			}
			this.$callbacks[key] = fun;
		}

		if (this.$callbacks['update'] == null) {
			throw new Error('...');
		}
	}
	//----------------------------
	get id() {
		return this.$id;
	}
	//----------------------------
	getModel() {
		return this.$model;
	}
	//----------------------------
	getObserver() {
		return this.$model.getObserver();
	}
	//----------------------------
	// callback
	// 可能由 context.init() 或 ob.commit() 發動
	dataChanged(handle = null) {
		debugger;

		const $bb = $MB.get('bb');
		const observe = this.getObserver();

		// # listener
		if (observe.hasExecut(this)) {
			// 已經重複執行過
			let info = `<< doubleExecute listener(${this.$id})>>`
			console.log(info);
			return;
		}
		//-------------
		if (handle == null) {
			handle = observe.createCommitHandle();
		}
		// 確保通知 context listener.dataUpdate()
		// 程序的結束
		const $context = this.$context || null;

		console.log(`listener(${this.$id}) dataUpdate()`)
		if (!this.$isInited) {
			this.$isInited = true;
		}
		// 重要的地方
		// 清除之前的依賴
		this.clearWatch();

		// 避免 listener double 執行
		// 只有在 commit 週期有用
		observe.addExecutListener(this);

		// 可以知道現在運行的 listener
		// 即使在套嵌的狀況下

		this._addActiveListener(handle);
		//-------------
		debugger;

		// 備用
		let fun_updated;
		const def = $bb.$deferred();

		let args = {
			listener: this,
			handle,
			promise: def.promise,
			updated(fun) {
				fun_updated = fun;
			}
		};

		debugger;
		let fun = this.$callbacks.update;
		let pr_1 = fun.call($context, args);

		debugger;
		if (pr_1 instanceof Promise) {
			// 若是非同步步驟
			handle.add(pr_1);
		}
		//-------------
		{
			// test
			console.log(`-----listener(${this.$id}).dataChanged()-----`);
			console.dir(this.$depList);
			console.log('----------');
		}
		debugger;
		this._removeActiveListener(handle);
		//-------------
		// 備用
		// 通知 listener.dataUpdated() 完成
		def.resolve();

		if (typeof(fun_updated) == 'function') {
			fun_updated();
		}
	}
	//----------------------------
	// API
	// 當依存的數據不在了
	remove() {
		debugger;

		//-------------
		let fun = this.$callbacks.remove;
		if (fun != null) {
			debugger;
			fun.call(this.$context);
		}
		//-------------
		let model = this.$model;
		this.$model = undefined;

		this.clearWatch();
		//-------------
		this._destroy();
	}
	//----------------------------
	isEqual(obj) {
		if (!(obj instanceof Model_listener)) {
			return false;
		}
		let res = (this.$id == obj.$id);
		return res;
	}
	//----------------------------
	addWatch(ob, key) {
		// debugger;

		ob.addListener(this);

		// debugger;
		if (!this.$depList.has(ob)) {
			this.$depList.set(ob, new Set());
		}
		let list = this.$depList.get(ob);
		list.add(key);
	}
	//----------------------------
	isMatch(changeList) {
		 // debugger;
		let propChange = this.$propChange;
		if (propChange) {
			// propData 有變動
			this.$propChange = false;
		}

		if (!this.$isInited) {
			return true;
		}
		if (propChange) {
			return true;
		}
		let find = false;

		loop: {
			for (let [ob_id, keyList] of changeList) {
				// debugger
				if (this.$depList.has(ob_id)) {
					let keyList_1 = this.$depList.get(ob_id);
					for (let key of keyList) {
						// debugger;
						if (keyList_1.has(key)) {
							find = true;
							break loop;
						}
					}
				}
			} //for
		} // loop

		return find;
	}
	//----------------------------
	propUpdate() {
		this.$propChange = true;
		let ob = this.getObserver();
		ob.addPropUpdate(this);
	}
	//----------------------------
	clearWatch(ob = null) {
		// debugger;
		if (ob == null) {
			for (let [ob, keyList] of this.$depList) {
				// debugger;
				this.$depList.delete(ob);
				keyList.clear();
				ob.removeListener(this);
			}
		} else {
			if (this.$depList.has(ob)) {
				let list = this.$depList.get(ob);
				this.$depList.delete(ob);
				list.clear();
			}
			ob.removeListener(this);
		}
	}
	//----------------------------
	/*
	 // 次要功能
	 clearExcute() {
	 let ob = this.$model.getObserver();
	 ob.clearExcute(this);
	 }
	 */
	//----------------------------
	_addActiveListener(handle) {
		handle.addActiveListener(this);
		const global = $MB.get('global');
		global.addActiveListener(this);
	}

	_removeActiveListener(handle) {
		handle.removeActiveListener(this);
		const global = $MB.get('global');
		global.removeActiveListener(this);
	}
	//----------------------------
	_destroy() {
		let names = Object.getOwnPropertyNames(this);
		while (names.length > 0) {
			let name = names.pop();
			this[name] = undefined;
			delete(this[name]);
		}
	}
}
//////////////////////////////

export function handle(mb) {
	$MB = mb;
	return Model_listener;
}
