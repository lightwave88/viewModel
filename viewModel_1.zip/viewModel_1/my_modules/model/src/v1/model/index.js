import MB from '../../mb.js';
const $mb = new MB();
//-------------
import {
  handle as h_listener
} from './m_listener.js';
$mb.importHandle('MListener', h_listener);
//-------------
import {
  handle as h_model
} from './model.js';
$mb.importHandle('Model', h_model);
//-------------
$mb.export(function() {
  const Model = this.get('Model');
  const MListener = this.get('MListener');
  return {
    Model,
    MListener
  };
});

export default $mb;
