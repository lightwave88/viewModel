let $MB;

class ViewModelGlobal{
  $activeListeners = [];
  //-----------------------
  // active
  addActiveListener(obj) {
    this.$activeListeners.push(obj);
  }

  // active
  removeActiveListener(obj) {
    let obj_1 = this.$activeListeners.pop();
    if (!obj_1.isEqual(obj)) {
      throw new Error('...');
    }
  }

  // active
  curretActiveListener() {
    // debugger;
    let length = this.$activeListeners.length;
    if (length == 0) {
      return null;
    }
    let listener = this.$activeListeners[length - 1];
    return listener;
  }

  getActiveListeners() {
    return this.$activeListeners;
  }
  //-----------------------
}

export function handle(mb){
  // debugger;
  $MB = mb;
  const global = new ViewModelGlobal();
  return global;
}
