let $MB;

function $modelAPI(data) {
	let res = $modelAPI.create(data);
	return res;
}
//-----------------------
// modelAPI
let $expand = {
	create(data) {
		// debugger;
		const Model = $MB.get('Model');

		if (data instanceof Model) {
			return data;
		}
		let model = Model.create(data);
		return model;
	},
	//------------------
	getRawData(data) {
		const $tools = $MB.get('tools');
		let rawData = $tools.getRawData(data);
		return rawData;
	},
	//------------------
	commit(data) {
		debugger;
		const $tools = $MB.get('tools');
		let ob = $tools.getObserver(data);
		if (ob == null) {
			return;
		}
		ob.commit();
	},
	//------------------
	// 儘量保存舊數據。同結構數據用修改替代代替爲全新
	updateData(oldData, newData) {
		debugger;
		const $tools = $MB.get('tools');
		$tools.deepMatch(oldData, newData);
	},
	//------------------
	getObserver(data) {
		let $tools = $MB.get('tools');
		return $tools.getObserver(data);
	},
	getRawData(data) {
		const $tools = $MB.get('tools');
		return $tools.getRawData(data);
	},
	getModelClass() {
		const Model = $MB.get('Model');
		return Model;
	},
	getListenerClass() {
		let ListenerProto = $MB.get('ListenerProto');
		return ListenerProto;
	},
	createListener(...args) {
		let Listener = $MB.get('Listener');
		return new Listener(args);
	},
	get tools() {

	},
	createProxy(data, _copy = false) {
		debugger;
		let react = $MB.get('react');
		let {
			ob,
			proxy
		} = react.createOb(data, _copy);
		debugger;
		return proxy;
	},
	$_createProp(data, _copy = false) {
		debugger;
		let react = $MB.get('react');
		let {
			ob,
			proxy
		} = react.createProp(data, _copy);
		return ob;
	}
};

Object.assign($modelAPI, $expand);
//-----------------------
// $modelAPI.tools
Object.defineProperty($modelAPI, 'tools', {
	get() {
		let tools = $MB.get('tools');
		return tools;
	},
	set(value) {}
});
/////////////////////////

export function handle(mb) {
	$MB = mb;
	return $modelAPI;
}
