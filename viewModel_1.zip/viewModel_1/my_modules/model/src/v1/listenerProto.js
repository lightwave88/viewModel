let $MB;

///////////////////////////////////
class LProto {
  $$$model;
  $$$wrap;
  //-----------------------
  constructor() {}
  //-----------------------
  get $data() {
    return this.$$$model.data;
  }
  //-----------------------
  get $model() {
    return this.$$$model;
  }
  //-----------------------
  $setData(data) {
    if (this.$$$model != null) {
      return;
    }
    if (typeof(data) == 'function') {
      data = data.call(this);
    }
    const Model = $MB.get('Model');
    this.$$$model = Model.create(data);
  }
  //-----------------------
  $commit() {
    return this.$$$model.commit();
  }
  //-----------------------
  $clearExcute() {
    debugger;
    this.$$$wrap.clearExcute();
  }
}
///////////////////////////////////
class ListenerProto extends LProto {
  //-----------------------
  constructor(args = null) {
    debugger;
    super();
  }
  //-----------------------
  $setData(data) {
    debugger;
    super.$setData(data);

    debugger;
    const effect = this.$$$model.effect({
      context: this,
      update: (args) => {
        return this.dataUpdate(args);
      },
      remove: () => {
        return this.dataRemove();
      }
    })

    this.$$$wrap = effect();
  }
  //-----------------------
  // API
  // override
  dataUpdate(args) {
    throw new Error('dataUpdate need override');
  }
  //-----------------------
  // API
  // override
  dataRemove() {
    throw new Error('dataRemove need override');
  }
}
///////////////////////////////////

class Listener extends LProto {
  $$$callbacks = {
    init: undefined,
    dataUpdate: undefined,
    dataRemove: undefined,
  };
  //-----------------------
  constructor(args = []) {
    debugger;
    super();

    let settings = {};

    while (args.length > 0) {
      let arg = args.shift();
      Object.assign(settings, arg)
    }
    //-------------
    let key = '$data';
    if (key in settings) {
      let data = settings[key];
      delete(settings[key]);
      this.$setData(data);
    }
    //-------------
    // 取得 callback
    for (let key in this.$$$callbacks) {
      let k = '$' + key;
      if (k in settings) {
        this.$$$callbacks[key] = settings[k];
        delete(settings[k]);
      }
    }
    //-------------
    debugger;
    // extend
    Object.assign(this, settings);
    //-------------
    // callback.$init
    let fun = this.$$$callbacks.init;
    if (fun != null) {
      fun.call(this);
    }
    //-------------
    if(this.$$$model == null){
      throw new Error('no model');
    }

    const effect = this.$$$model.effect({
      context: this,
      update: (args) => {
        // debugger;
        return this.$_dataUpdate(args);
      },
      remove: () => {
        return this.$_dataRemove();
      }
    });

    this.$$$wrap = effect();
  }
  //-----------------------
  $_dataUpdate(args) {
    // debugger;
    let res;

    let fun = this.$$$callbacks.dataUpdate;
    if (fun != null) {
      res = fun.call(this, args);
    }
    return res;
  }
  //-----------------------
  $_dataRemove() {
    debugger;
    let fun = this.$$$callbacks.dataRemove;
    if (fun != null) {
      res = fun.call(this, args);
    }
  }
  //-----------------------
}
///////////////////////////////////
export function handle(mb) {
  $MB = mb;
  return {
    ListenerProto,
    Listener
  };
}
