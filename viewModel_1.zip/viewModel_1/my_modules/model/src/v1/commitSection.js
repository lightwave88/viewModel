let $MB;
let $UID = 0;

// 模擬非同步時間等待時間
const $time = 1000 * 10 * 0;

class CommitSection {
	$id;
	$def;
	//-------------
	// set()
	// 避免 commit 周期內 listener 重複執行
	$executListeners = new Set();
	$activeListeners = [];
	//-------------
	$waitingList = new Set();
	$rootList = new Map();

	// 判斷是否進入 commit()
	$isOnCommit = false;
	$observer;
	$count = 0;
	//-----------------------
	constructor(ob) {
		const $bb = $MB.get('bb');
		this.$def = $bb.$deferred();
		this.$id = $UID++;

		this.$observer = ob;
	}
	//-----------------------
	worksPromise() {
		debugger;
		let waitList = Array.from(this.$waitingList);

		let pr = Promise.all(waitList);

		pr.then(() => {
			// this.$waitingList.clear();
		}, (err) => {
			this.reject();
			throw err;
		});
		return pr;
	}
	//-----------------------
	// 當被呼叫 end()
	get promise() {
		// debugger;
		return this.$def.promise;
	}
	//-----------------------
	isAllDone() {
		// debugger;
		let res = (this.$waitingList.size == 0);
		return res;
	}
	//-----------------------
	// 確定 commitHandke 的型別
	isInitType() {
		return this.$isInitType;
	}
	//-----------------------
	// 旗標作用
	doCommit() {
		// 進入執行 commit()
		if (this.$isOnCommit) {
			return;
		}
		this.$isOnCommit = true;
	}

	isOnCommit() {
		debugger;
		return this.$isOnCommit;
	}
	//-----------------------
	isEqual(cp) {
		if (!(cp instanceof CommitSection)) {
			return false;
		}
		return (this.$id == cp.$id);
	}
	//-----------------------
	// 登記非同步任務
	add(pr) {
		debugger;
		if (!(pr instanceof Promise)) {
			throw new TypeError('...');
		}

		if (this.$waitingList.has(pr)) {
			return;
		}
		pr.then(() => {
			debugger;
			this.$waitingList.delete(pr);
		});
		this.$waitingList.add(pr);
	}
	//-----------------------
	resolve() {
		// debugger;
		this._callRoots();
		this.$def.resolve();
		this._destroy();
	}
	//-----------------------
	reject() {
		this.$def.reject();
		this._destroy();
	}
	//-----------------------
	// 特殊 view 專用
	// 傳入 view.root
	addRoot(view, callback) {

		if (typeof(callback) != 'function') {
			throw new TypeError('...');
		}
		if (!this.$rootList.has(view)) {
			this.$rootList.set(view, callback);
		}
	}
	//-----------------------
	// 叫 view 執行
	_callRoots() {
		debugger;
		for (let [view, callback] of this.$rootList) {
			debugger;
			this.$rootList.delete(view);
			callback.call(view);
		}
	}
	//-----------------------
	// executed
	addExecutListener(obj) {
		// debugger;
		this.$executListeners.add(obj);
	}

	// executed
	hasExecuted(listener) {
		// debugger;
		return this.$executListeners.has(listener);
	}

	// executed
	addExecuted(listener) {
		this.$executListeners.add(listener);
	}

	// executed
	clearExcute(listener = null) {
		if (listener == null) {
			this.$executListeners.clear();
		} else {
			this.$executListeners.delete(listener);
		}
	}

	getExecuteds() {
		return this.$executListeners;
	}
	//-----------------------
	// 用不到
	// 轉移資料
	copyWith(commitH) {
		debugger;

		if (this.isOnCommit() || commitH.isOnCommit()) {
			throw new Error('...');
		}
		/*
		 let activeListeners = commitH.getActiveListeners();
		 let waitings = commitH.getWaitings();

		 if(activeListeners.length > 0){
		 // 會造成執行次序錯誤
		 throw new Error('...');
		 }
		 if(waitings.length > 0){
		 // 會造成 promise 的錯誤
		 throw new Error('...');
		 }
		 *
		 */
		//-------------
		// copy roots
		let rootList = commitH.getRoots();
		for (let [root, callback] of rootList) {
			this.addRoot(root, callback);
		}

		// copy $executListeners
		let executeds = commitH.getExecuteds();
		for (let listener of executeds) {
			this.addExecuted(listener);
		}
		commitH._destroy();
	}
	//-----------------------
	getRoots() {
		return this.$rootList;
	}
	//-----------------------
	addActiveListener(listener) {
		this.$activeListeners.push(listener);
	}

	removeActiveListener(listener) {
		let remove = this.$activeListeners.pop(listener);
		if (!listener.isEqual(remove)) {
			throw new Error('...');
		}
	}

	checkListenerStatus() {
		// debugger;
		if (this.$activeListeners.length > 0) {
			throw new Error('...');
		}
	}
	//-----------------------
	/*
	isBusy() {
		let res = (this.$waitingList.szie > 0) ? true : false;
		return res;
	}
	*/
	//-----------------------
	_destroy() {
		this.$executListeners.clear();
		this.$rootList.clear();
		this.$waitingList.clear();
		// this.$activeListeners.length = 0;

		let names = Object.getOwnPropertyNames(this);
		for (let name in names) {
			this[name] = undefined;
			delete(this[name]);
		}
	}
	//-----------------------
}
////////////////////////////////////////

function forTest(handle) {
	// 故意加入
	let pr = new Promise((res) => {
		setTimeout(() => {
			debugger;
			// commitHandle
			res();
		}, $time);
	});

	handle.add(pr);
}

export function handle(mb) {
	$MB = mb;
	return CommitSection;
}