// debugger;
import MB from '../mb.js';
const $mb = new MB();
//-------------
import {
	handle as h_config
} from './config.js';
$mb.importHandle('config', h_config);
//-------------
import m_tools from './tools/index.js';
$mb.importModule('tools', m_tools);
//-------------
import {
	handle as h_modelAPI
} from './modelAPI.js';
$mb.importHandle('modelAPI', h_modelAPI);
//-------------
import m_react from './react/index.js';
$mb.importModule(['react', 'Observer', 'PropObserver'], m_react);
//-------------
import m_model from './model/index.js';
$mb.importModule(['Model', 'MListener'], m_model);
//-------------
import {
	handle as h_commitS
} from './commitSection.js';
$mb.importHandle('CommitSection', h_commitS);
//-------------
/*
import {
	handle as h_listener
} from './listenerProto.js';
$mb.importHandle(['ListenerProto', 'Listener'], h_listener);
*/
//-------------
import {
	handle as h_global
} from './global.js';
$mb.importHandle('global', h_global);
//-------------
export function handle(bb) {
	$mb.import('bb', bb);
	let modelAPI = $mb.get('modelAPI');
	bb['vModel'] = modelAPI;
	$mb.finish();
}