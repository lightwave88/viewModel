let $MB;

const $react = {};

function _copyValue(data) {
	const $tools = $MB.get('tools');
	let ob = $tools.getObserver(data);
	if (ob != null) {
		return data;
	};
	data = JSON.parse(JSON.stringify(data));
	return data;
}
//-----------------------
function _addProxy(data, isProp) {
	// debugger;
	const $tools = $MB.get('tools');

	if (typeof(data) == 'object') {
		if (!(Array.isArray(data) || $tools.isPlainObject(data))) {
			// 物件只能是兩種格式
			throw new Error('...');
		}
		if ($tools.hasObserver(data)) {
			let ob = $tools.getObserver(data);
			return ob;
		}
	} else {
		// 簡單數值
		throw new Error('...');
	}
	//------------
	// debugger;
	let ob;
	if (isProp) {
		const PropObserver = $MB.get('PropObserver');
		ob = new PropObserver(data);
	} else {
		const Observer = $MB.get('Observer');
		ob = new Observer(data);
	}
	return ob;
}
//-----------------------
(() => {
	function _walkArray(data, p_ob) {
		// debugger;
		for (let i = 0; i < data.length; i++) {
			// debugger;

			let value = data[i];
			let {
				proxy,
			} = makeObserver(value, p_ob);
			data[i] = (proxy != null) ? proxy : value;
		}
	}
	//-----------------------
	function _walkPlainObject(data, p_ob) {
		// debugger;
		for (let key in data) {
			// debugger;

			let value = data[key];
			let {
				proxy,
			} = makeObserver(value, p_ob);
			data[key] = (proxy != null) ? proxy : value;
		}
	}
	//-----------------------
	// API
	function makeObserver(data, parent = null, isProp = false) {
		// debugger;

		const $tools = $MB.get('tools');
		const PropObserver = $MB.get('PropObserver');

		let ob;

		if (!isProp && parent != null) {
			if (parent instanceof PropObserver) {
				isProp = true;
			}
		}
		if (data == null || typeof(data) != 'object') {
			return {
				value: data,
				ob,
			};
		}
		//-------------
		if ($tools.hasObserver(data)) {
			ob = $tools.getObserver(data);

			if (parent != null) {
				debugger;
				ob.setParent(parent);
			}
			return {
				value: ob.$raw,
				ob,
				proxy: ob.$proxy,
			};
		}
		//-------------
		// 加入追蹤功能
		ob = _addProxy(data, isProp);
		// debugger;
		if (parent != null) {
			ob.setParent(parent);
		}
		//-------------
		// debugger;
		const rawData = ob.$raw;
		let proxy = ob.$proxy;

		if (Array.isArray(rawData)) {
			_walkArray(rawData, ob);
		} else if ($tools.isPlainObject(rawData)) {
			_walkPlainObject(rawData, ob);
		}
		//-------------
		// debugger;
		return {
			value: ob.raw,
			ob,
			proxy
		};
	}
	//////////////////////////////
	// API
	$react.createOb = function(data, _copy = false) {
		if (_copy) {
			data = _copyValue(data);
		}
		return makeObserver(data);
	};
	//-------------
	// 內部使用
	$react._createOb = function(data, parent = null) {
		return makeObserver(data, parent);
	}
	//-------------
	// API
	$react.createProp = function(data, _copy = false) {
		if (_copy) {
			data = _copyValue(data);
		}
		return makeObserver(data, null, true);
	};
	//-------------
	// 內部使用
	$react._createProp = function(data, parent = null) {
		return makeObserver(data, parent, true);
	};
})($react);
///////////////////////////////////
export function handle(mb) {
	$MB = mb;
	return $react;
};
