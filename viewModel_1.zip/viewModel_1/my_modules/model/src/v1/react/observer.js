import {
ObserverProto
        } from './obProto.js';
let $MB;
let $UID = 0;

class Observer extends ObserverProto {

  $models = new Set();

  // 傾聽者
  // 爲了避免 listener 記憶體泄漏用
  $listeners = new Set();
  //--------
  // for test
  // Map
  $depList;
  //-------------
  // $isTrigger;

  // 當 child 切換位置時會用到
  $isSwitchingPos;

  // []
  // 讓資料變化不會發出訊號
  $keepSilence = false;

  // 確定資料是否改變過
  $checkPoint;
  //-----------------------
  // Set
  $propUpdateList;

  $commitHandle;
  //-----------------------
  constructor(data) {
    // debugger;
    super(data);

    this.$id = 'ob_' + $UID++;
  }
  //-----------------------
  get id() {
    return this.$id;
  }

  get rawData() {
    return this.$raw;
  }

  get data() {
    return this.$proxy;
  }

  // [] 是否使用了方法
  get arrayMethod() {
    if (!this.$isArray) {
      throw new Error('...');
    }
    return (this.$arrayMethod || null);
  }
  // set [].length 會用到
  get prevLength() {
    if (!this.$isArray) {
      throw new Error('...');
    }
    return this.$prevLength;
  }

  get root() {
    let ob = this;
    let root;
    while (ob != null) {
      root = ob;
      ob = ob.$parent;
    }
    return root;
  }
  //-----------------------
  // 傾聽者
  // 當 ob.remove 時通知與他有關的 listener 之間不再有關係
  addListener(listener) {
    this.$listeners.add(listener);
  }

  // 當 listener.remove 時，通知 ob 刪除他
  removeListener(listener) {
    if (this.$listeners.has(listener)) {
      this.$listeners.delete(listener);
    }
  }
  //-----------------------
  // main
  setParent(parent) {
    // debugger;
    // const $root = parent.root;

    let isRoot = this._setParentCheck(parent);
    //-------------
    // debugger;
    if (isRoot) {
      // 把資料移轉移

      if (this.$changeList != null) {
        for (let [ob, keyList] of this.$changeList) {
          this.$changeList.delete(ob);
          for (let key of keyList) {
            parent.addChange(ob, key);
          }
          keyList.clear();
        }
        this.$changeList = undefined;
      }
      //-------------
      // debugger;
      // for test
      if (this.$depList != null) {
        for (let [ob, list] of this.$depList) {
          this.$depList.delete(ob);
          for (let key of list) {
            parent._addDeps(ob, key);
          }
          list.clear();
        }
      }      
    }
    //-------------
    this.$parent = parent;
    parent.$childs.add(this);
  }
  //-------------
  // 當 ob 所屬的 data 在同一個 parent 切換位址
  // ob 不用被刪除
  switchingPos() {
    this.$isSwitchingPos = true;
  }
  //-----------------------

  getSilence() {

  }

  // sub
  silence(silence) {

    if (silence == null) {
      silence = false;
    }
    let check = silence + '';

    // 參數格式監察
    switch (check) {
      // 對於數據的讀取，修改都不反應
      case 'true':
      // 恢復原設定
      case 'false':
      case 's':
      // 不對 set 有反應
      case 'r':
        // 不對 get 有反應
        break;
      default:
        // 不對的格式
        throw new TypeError('...');
        return;
    }
    let root = this.root;
    let value = root.$keepSilence;
    root.$keepSilence = silence;
    return value;
  }
  //-----------------------
  // main
  // 與 parent 斷除關係
  remove() {
    debugger;
    const $tools = $MB.get('tools');
    // 由上往下

    if (this.$isSwitchingPos == true) {
      // 特殊狀況
      // 不是真的要 remove
      // 而是要 child 交換位置
      this.$isSwitchingPos = undefined;
      if (this.$parent != null) {
        this.$parent.removeChild(this);
        this.$parent = undefined;
      }
      return;
    }
    //-------------
    // 由上往下，廣域
    let obList = [this];

    for (let i = 0; obList[i] != null; i++) {
      debugger;
      let ob = obList[i];
      for (let child of ob.$childs) {
        obList.push(child);
      }
      // 通知 models
      ob._remove();
    }
    //-------------
    setTimeout(() => {
      // 叫所有 childs destroy
      for (var i = 0; i < obList.length; i++) {
        let ob = obList[i];
        ob._destroy();
      }
    }, 0);
  }
  //-----------------------
  // main
  // 由 proxy 呼叫
  emit(args = {}) {
    // debugger;
    if (this.$parent != null) {
      return this.root.emit(args);
    }
    //-------------
    let {
      key,
      action,
      ob,
    } = args;

    const $keepSilence = this.$keepSilence;

    if (action == 'read') {
      debugger;
      // read data

      switch ($keepSilence) {
        case true:
        case 'r':
          return;
          break;
      }

      let listener = this.curretActiveListener();
      debugger;
      if (listener != null) {
        listener.addWatch(ob, key);
      }

      // for test
      this._addDeps(ob, key);
    } else {
      debugger;
      // set data

      switch ($keepSilence) {
        case true:
        case 's':
          return;
          break;
      }
      this.addChange(ob, key);
  }
  }
  //-----------------------
  // main
  commit() {
    debugger;

    if (this.$parent != null) {
      // 回朔到 root
      return this.root.commit();
    }
    //-------------
    // root
    debugger;

    if (this.$commitHandle == null) {
      this.createCommitHandle();
    } else {
      if (this.$commitHandle.isOnCommit()) {
        let pr = this.$commitHandle.promise;
        return pr;
      }
    }

    //  檢查
    // this._checkListenerStatus();
    this.$commitHandle.checkListenerStatus();

    this.$commitHandle.doCommit();
    debugger;
    //-------------
    let commitHandle;
    let pr = (async () => {
      commitHandle = this.$commitHandle;

      end: {
        debugger;
        // debugger;
        while (true) {
          debugger;
          console.log('commit loop .........')
          // 針對 init 衆多的 commit
          // 等待 _commit() 激發的所有任務完成 render()
          await commitHandle.worksPromise();
					debugger;
          if (commitHandle.isAllDone()) {
            break;
          }
        }
        //-------------
        debugger;
        console.log('check isDataChange');

        // 迴圈最主要迴圈的目的
        // 怕 commit 周期內有人修改了數據
        if (!this.isDataChange()) {
          break end;
        }
        //-------------
        // sendRequest
        // 與資料庫通訊

        //-------------
        // 複製 this.$changeList 並清除記錄
        let changeList = this._copyChangeList();

        // 主要任務
        // 通知大家數據變了
        this._commit(changeList, commitHandle);
				
				debugger;
        await commitHandle.worksPromise();
				debugger;
      } // end
      //------------------
      debugger;
      let handle = this.$commitHandle;
      this.$commitHandle = undefined;
      handle.resolve();
      console.log('data commit end');

      // for test
      this.clearDeps();
    })(); // async
    //-------------
    pr.catch((err) => {
      // debugger;
      console.dir(err);
      commitHandle.reject();
      throw err;
    });

    return pr;
  }
  //-----------------------
  // model init 會遺留數據變動的訊息
  // 必須清除
  clearChanges() {
    if (this.$parent != null) {
      // 往 root 追朔
      let root = this.root;
      root.clearChanges();
      return;
    }
    //-------------
    if (this.$changeList != null) {
      for (let [ob, keyList] of this.$changeList) {
        this.$changeList.delete(ob);
        keyList.clear();
      }
    }
  }
  //-----------------------
  // main
  addModel(model) {
    this.$models.add(model);
  }
  //-----------------------
  // 關於 listener

  // 會往 rootOb 傳送
  // 除了 commit() 會用到，model.effect() 也會用到
  /*
   addActiveListener(obj) {
   // debugger;
   if (this.$parent != null) {
   // 往上回朔
   let root = this.root;
   return root.addActiveListener(obj);;
   }
   //-------------
   // debugger;
   this.$commitHandle.addActiveListener(obj);
   }
   */
  //-----------------------
  // 會往 rootOb 傳送
  /*
   removeActiveListener(obj) {
   // debugger;
   if (this.$parent != null) {
   // 往上回朔
   let root = this.root;
   return root.removeActiveListener(obj);
   }
   //-------------
   this.$commitHandle.removeActiveListener(obj);
   }
   */
  //-----------------------
  curretActiveListener() {
    // debugger;
    let global = $MB.get('global');
    let listener = global.curretActiveListener();
    return listener;
  }
  //-----------------------

  addExecutListener(obj) {
    // debugger;
    if (this.$parent != null) {
      // 往上回朔
      let root = this.root;
      return root.addExecutListener(obj);
    }
    //-------------
    // debugger;
    this.$commitHandle.addExecuted(obj);
  }

  /*
   removeExecutListeners(obj) {
   if (this.$parent != null) {
   // 往上回朔
   let root = this.root;
   return root.removeExecutListeners(obj);
   }
   //-------------
   // debugger;
   this.$commitHandle.delete(obj);
   }
   */

  /*
   clearExecutListeners() {
   if (this.$parent != null) {
   // 往上回朔
   let root = this.root;
   return root.clearExecutListeners(obj);
   }
   //-------------
   // debugger;
   if (this.$executListeners != null) {
   this.$executListeners.clear();
   }
   }
   */
  // listener 是否執行過
  hasExecut(obj) {
    // debugger;
    if (this.$parent != null) {
      // 往上回朔
      let root = this.root;
      return root.hasExecut(obj);
    }
    //-------------
    // debugger;
    if (this.$commitHandle == null) {
      return false;
    }
    let res = this.$commitHandle.hasExecuted(obj);
    return res;
  }
  //-----------------------
  isHasModel(model = null) {
    debugger;
    let res = false;
    if (model == null && this.$models.size > 0) {
      res = true;
    } else {
      for (let m of this.$models) {
        if (m.isEqaul(model)) {
          res = true;
          break;
        }
      } // for
    }
    return res;
  }
  //-----------------------
  // 輔助功能
  // 確定 checkPointStart - checkPointEnd 之間
  // 資料是否改變過
  checkPointStart() {
    this.$checkPoint = 0;
  }

  checkPointEnd() {
    if (this.$checkPoint == null) {
      throw new Error('no checkStart()');
    }
    count = this.$checkPoint;
    this.$checkPoint = undefined;
    return count > 0;
  }
  //-----------------------
  /*
   clearExcute(listener = null) {
   if (this.$parent != null) {
   return this.root.clearExcute();
   }
   //-------------
   debugger;
   if (this.$commitHandle == null) {
   return;
   }
   this.$commitHandle.clearExcute(listener);
   }
   */
  //-----------------------
  addPropUpdate(listener) {
    if (this.$parent != null) {
      let root = this.root;
      return root.addPropUpdate(listener);
    }
    //-------------
    debugger;
    if (this.$propUpdateList == null) {
      this.$propUpdateList = new Set();
    }
    this.$propUpdateList.add(listener);
  }
  //-----------------------
  // top down 的過程
  _commit(changeList, handle) {
    debugger;

    // throw new Error('...');

    if (this.$parent != null) {
      throw new Error('...');
    }
    // 由上往下的過程，廣域模式
    // 可以改成由下往上
    let obList = [this];

    for (let i = 0; obList[i] != null; i++) {
      // debugger;
      let ob = obList[i];
      // console.dir(ob);

      for (let model of ob.$models) {
        // model 呼叫 listener
        // debugger;
        model.$_dataChanged(changeList, handle);
      }

      for (let child_ob of ob.$childs) {
        obList.push(child_ob);
      }
    } // for

    obList.length = 0;
  }
  //-----------------------
  _remove() {
    debugger;
    if (this.$parent != null) {
      this.$parent.removeChild(this);
      this.$parent = undefined;
    }

    for (let listener of this.$listeners) {
      debugger;
      this.$listeners.delete(listener)
      listener.clearWatch(this);
    }
    for (let model of this.$models) {
      debugger;
      this.$models.delete(model);
      model.$_remove();
    }
    //-------------
    /*
     if (this.$executListeners != null) {
     this.$executListeners.clear();
     }
     */
  }
  //-----------------------
  _destroy() {
    super._destroy();
  }
  //-----------------------
  _copyChangeList() {
    // 複製 this.$changeList 並清除記錄
    let cloneData = new Map();

    for (let [ob, keyList] of this.$changeList) {
      this.$changeList.delete(ob);
      let cloneList = new Set(keyList);
      keyList.clear();
      cloneData.set(ob, cloneList);
    }
    return cloneData;
  }
  //-----------------------
  addChange(ob, key) {

    if (this.$parent != null) {
      return this.root.addChange(ob, key);
    }
    //-------------
    if (!(ob instanceof Observer)) {
      console.dir(ob);
      alert('error');
      throw new Error('...');
    }

    if (this.$changeList == null) {
      this.$changeList = new Map();
    }
    if (!this.$changeList.has(ob)) {
      this.$changeList.set(ob, new Set());
    }
    let list = this.$changeList.get(ob);

    let size = list.size;
    list.add(key);

    if (this.$checkPoint != null && (list.size > size)) {
      ++this.$checkPoint;
    }
  }
  //-----------------------
  // for test
  _addDeps(ob, key) {
    if (this.$parent != null) {
      return this.root._addDeps(ob, key);
    }
    //-------------
    if (this.$depList == null) {
      this.$depList = new Map();
    }
    if (!this.$depList.has(ob)) {
      this.$depList.set(ob, new Set());
    }
    let list = this.$depList.get(ob);
    list.add(key);
  }
  //-----------------------
  // for test
  clearDeps() {
    if (this.$parent != null) {
      return this.root.clearDeps(ob, key);
    }
    //-------------
    if (this.$depList == null) {
      return;
    }
    for (let [ob, list] of this.$depList) {
      list.clear();
      this.$depList.delete(ob);
    }
  }
  //-----------------------
  getDeps(isPlainObject = false) {
    if (this.$parent != null) {
      return this.root.getDeps();
    }
    //-------------
    if (isPlainObject) {
      let res = {};
      if (this.$depList != null) {
        for (let [ob, list] of this.$depList) {
          let id = ob.id;
          list = Array.from(list);
          res[id] = list;
        }
      }
      return res;
    }
    return this.$depList;
  }
  //-----------------------
  isDataChange() {
    if (this.$parent != null) {
      return this.root.isDataChange();
    }
    //-------------
//		debugger;

    const $bb = $MB.get('bb');

    // for test
    this._showChanges(this.$changeList);

    console.log('isDataChange.....');
    console.log('changeList = ');
//		debugger;
    let showData = $bb.copyValue(this.$changeList);
//		debugger;
    console.dir(showData);
//		debugger;
    console.log('$propUpdateList = ');
    showData = $bb.copyValue(this.$propUpdateList);
    console.dir(showData);

    let res_1 = (this.$changeList != null && this.$changeList.size > 0);
    let res_2 = (this.$propUpdateList != null && this.$propUpdateList.size > 0);
    if (res_2) {
      // reset
      this.$propUpdateList.clear();
    }
    return (res_1 || res_2);
  }
  //-----------------------
  // test
  _showChanges(data) {
    let res = {};
    if (data != null) {
      for (let [ob, list] of data) {
        res[ob.id] = Array.from(list);
      }
    }
    console.log('changeKeys = ' + JSON.stringify(res));
  }
  //-----------------------
  // 避免 listenr.dataChanged() 過程還沒完成
  // 就呼叫了 ob.commit()
  _checkListenerStatus() {

    const global = $MB.get('global');
    let listeners = global.getActiveListeners();

    if (listeners.length > 0) {
      // error
      /*
       避免 listenr.dataChanged() 過程還沒完成
       就呼叫了 ob.commit()
       */
      let index = listeners.length - 1;
      let listener = listeners[index];

      let err = `listener(${listener.id}) commit() must await listener.dataUpdate() finish`;
      throw new Error(err);
    }
  }
  //-----------------------
  // commitHandle
  // isCommit: 是否是在 commit() 週期生成的
  createCommitHandle() {

    if (this.$parent != null) {
      return this.root.createCommitHandle();
    }
    //-------------
    // debugger;
    // root
    const CommitSection = $MB.get('CommitSection');
    if (this.$commitHandle != null) {
      return this.$commitHandle;
    }
    let commitH = new CommitSection(this);
    this.$commitHandle = commitH;
    return commitH;
  }
  //-----------------------
  // commitHandle
  isOnCommit() {
    if (this.$parent != null) {
      return this.root.isOnCommit();
    }
    //-------------
    // debugger;
    if (this.$commitHandle == null) {
      return false;
    }
    let status = this.$commitHandle.isOnCommit();
    return status;
  }
  //-----------------------
  // for model.isOnCommit()
  // 確保在 commit() 週期內不要提交數據變化
  isOnCommit_forModel() {
    if (this.$parent != null) {
      return this.root.isOnCommit_forModel;
    }
    //-------------
    return (this.$commitHandle != null);
  }
  //-----------------------
  // setParent 的 check
  _setParentCheck(parent) {
    // debugger;
    if (!(parent instanceof Observer)) {
      throw new Error('...');
    }
    let isRoot = false;
    if (this.$parent == null) {
      // is root

      isRoot = true;
      if (this.$commitHandle != null) {
        // 正在執行 commit()
        throw new Error('...');
      }
    } else {
      if (!this.$parent.isEqual(parent)) {
        // 不可以隸屬多個數據樹
        throw new Error('...');
      } else {
        if (!this.isSwitchingPos && parent.arrayMethod == null) {
          console.dir(this);
          throw new Error('...');
        }
      }
    }
    return isRoot;
  }
  //-----------------------
} // class

////////////////////////////////////////

export function handle(mb) {
  //	debugger;
  $MB = mb;
  //	console.log(Observer.time);
  return Observer;
}
