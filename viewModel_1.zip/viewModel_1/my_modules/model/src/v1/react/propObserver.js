import {
	ObserverProto
} from './obProto.js';
let $MB;
let $UID = 0;

class PropObserver extends ObserverProto {

	//-----------------------
	constructor(data) {
		super(data);

		this.$id = 'prop_' + $UID++;
	}
	//-----------------------
	// main
	emit(args) {
		debugger;
		let {
			key,
			action,
			ob,
		} = args;

		if (action == 'set') {
			debugger;
			let root = this.root;
			root.addChange(ob, key);
		}
	}
	//-----------------------
	isDataChange(clear = false) {
		if (this.$parent != null) {
			return this.root.isDataChange();
		}
		//-------------
		debugger;
		let res = (this.$changeList != null && this.$changeList.size > 0);

		if (clear && this.$changeList != null) {
			// 清除
			for (let [ob, keyList] of this.$changeList) {
				this.$changeList.delete(ob);
				keyList.clear();
			}
		}
		return res;
	}
	//-----------------------
	// main
	setParent(parent) {
		debugger;

		if (!(parent instanceof PropObserver)) {
			throw new Error('...');
		}
		if (this.$parent != null) {
			if (parent.isEqual(this.$parent)) {

				if (parent.arrayMethod != null) {
					return;
				} else {
					throw new Error('...');
				}
			} else {
				// 不可以隸屬多個數據樹
				throw new Error('...');
			}
		}
		//-------------
		// debugger;
		if (this.$changeList != null) {
			// 把資料移轉給 parent
			for (let [ob, keyList] of this.$changeList) {
				for (let key of keyList) {
					parent.addChange(ob, key);
				}
				keyList.clear();
				this.$changeList.delete(ob);
			}
			this.$changeList = undefined;
		}
		//-------------
		this.$parent = parent;
		parent.$childs.add(this);
	}
	//-----------------------
	addChange(ob, key) {

		if (this.$parent != null) {
			let root = this.root;
			return root.addChange(ob, key);
		}
		//-------------
		if (this.$changeList == null) {
			this.$changeList = new Map();
		}
		if (!this.$changeList.has(ob)) {
			this.$changeList.set(ob, new Set());
		}
		let list = this.$changeList.get(ob);
		list.add(key);
	}
	//-----------------------
	remove() {
		// 由上往下，廣域
		let obList = [this];

		for (let i = 0; obList[i] != null; i++) {
			debugger;
			let ob = obList[i];
			for (let child of ob.$childs) {
				obList.push(child);
			}
			// 通知 models
			ob._remove();
		}
		//-------------
		setTimeout(() => {
			// 叫所有 childs destroy
			debugger;
			for (var i = 0; i < obList.length; i++) {
				let ob = obList[i];
				ob._destroy();
			}
		}, 0);
	}
	//-----------------------
	_remove() {
		debugger;
		if (this.$parent != null) {
			this.$parent.removeChild(this);
			this.$parent = undefined;
		}
	}
}

export function handle(mb) {
//	debugger;
	$MB = mb;
//	console.log(PropObserver.time);
	return PropObserver;
}
