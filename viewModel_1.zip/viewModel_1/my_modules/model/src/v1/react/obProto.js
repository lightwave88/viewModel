//debugger;
let $MB;

class ObserverProto {
	$id;

	// 原本的數據
	$raw;
	// proxy
	$proxy;

	// proxy 的解構
	$revocable;
	//--------
	$parent;

	// 新的屬性,要往下傳播訊息用的
	$childs = new Set();

	// 確定 data 的型別
	$isArray = false;
	//--------
	// 是否有 arrayMethod 執行
	$arrayMethod;
	// 特殊
	$prevLength;
	//--------
	// 只有 root 才有
	$changeList;
	//-----------------------
	constructor(data) {
		// debugger;

		const $tools = $MB.get('tools');

		this.$raw = data;

		$tools.dataLinkOb(data, this);

		let proxySetting;
		if (Array.isArray(data)) {
			this.$isArray = true;
		} else if ($tools.isPlainObject(data)) {} else {
			throw new Error('...');
		}
		proxySetting = this._getProxySetting(data);

		this.$revocable = Proxy.revocable(data, proxySetting)
		this.$proxy = this.$revocable.proxy;
	}
	//-----------------------
	get id() {
		return this.$id;
	}

	get rawData() {
		return this.$raw;
	}

	get data() {
		return this.$proxy;
	}

	// [] 是否使用了方法
	get arrayMethod() {
		if (!this.$isArray) {
			throw new Error('...');
		}
		return (this.$arrayMethod || null);
	}
	// set [].length 會用到
	get prevLength() {
		if (!this.$isArray) {
			throw new Error('...');
		}
		return this.$prevLength;
	}

	get root() {
		let ob = this;
		let root;
		while (ob != null) {
			root = ob;
			ob = ob.$parent;
		}
		return root;
	}
	//-----------------------
	// API
	emit() {
		throw new Error('need override emit()');
	}
	//-----------------------
	setParent() {
		throw new Error('need override emit()');
	}
	//-----------------------
	remove() {
		throw new Error('need override remove()');
	}
	//-----------------------
	removeChild(ob) {
		if (this.$childs == null) {
			// has destroy
			return;
		}
		this.$childs.delete(ob);
	}
	//-----------------------
	// sub
	isEqual(ob) {
		if (!(ob instanceof ObserverProto)) {
			return false;
		}
		return (this.$id == ob.$id);
	}
	//-----------------------
	// setProxy
	_getProxySetting(data) {
		let setting;
		if (this.$isArray) {
			const getArrayProto = $MB.get('getArrayProto');
			const arrayProto = getArrayProto();
			Reflect.setPrototypeOf(data, arrayProto);

			const get_arrayProxySetting = $MB.get('get_arrayProxySetting');
			setting = get_arrayProxySetting(this);

		} else {
			const get_objProxySetting = $MB.get('get_objProxySetting');
			setting = get_objProxySetting(this);
		}
		return setting;
	}
	//-----------------------
	_destroy() {
		const $tools = $MB.get('tools');

		$tools.dataUnLinkOb(this.rawData);

		// 斷開數據樹
		if (Array.isArray(this.rawData)) {
			this.rawData.length = 0;
		} else {
			for (let k in this.rawData) {
				delete(this.rawData[k]);
			}
		}

		// 取消 proxy
		this.$revocable.revoke();

		let names = Object.getOwnPropertyNames(this);
		while (names.length > 0) {
			let name = names.pop();
			this[name] = undefined;
			delete(this[name]);
		}
	}
}

//ObserverProto.time = (new Date()).getTime();
//////////////////////////////
export function handle(mb) {
//	debugger;
	$MB = mb;
	return ObserverProto;
}

export {
	ObserverProto
};
