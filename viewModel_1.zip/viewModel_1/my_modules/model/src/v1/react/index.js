import MB from '../../mb.js';
const $mb = new MB();
//-------------
import {
	handle as h_react
} from './dataReact.js';
$mb.importHandle('react', h_react);
//-------------
import {
	handle as h_obProto
} from './obProto.js';
$mb.importHandle('ObProto', h_obProto);
//-------------
//debugger;
import {
	handle as h_ob
} from './observer.js';
$mb.importHandle('Observer', h_ob);
//-------------
import {
	handle as h_prop
} from './propObserver.js';
$mb.importHandle('PropObserver', h_prop);
//-------------
import {
	handle as h_arrayProto
} from './arrayMethod_debugger.js';
$mb.importHandle('getArrayProto', h_arrayProto);
//-------------
import {
	handle as h_arrayProxy
} from './arrayProxySetting_debugger.js';
$mb.importHandle('get_arrayProxySetting', h_arrayProxy);
//-------------
import {
	handle as h_objProxy
} from './objProxySetting_debugger.js';
$mb.importHandle('get_objProxySetting', h_objProxy);
//-------------
$mb.export(function() {
	let react = this.get('react');
	let Observer = this.get('Observer');
	let PropObserver = this.get('PropObserver');
	return {
		react,
		Observer,
		PropObserver
	};
});

export default $mb;
