let $MB;

// API
function get_objProxySetting($this) {

	const $react = $MB.get('react');
	const $tools = $MB.get('tools');
	const $config = $MB.get('config');
	const $indexName = $config['indexName'];
	//-----------------------
	return {
		// get
		get(target, key) {
			// debugger;
			console.log(`obj.get(${$toString(key)})`);

			if (_isGetRawdata(key)) {
				return target;
			}
			if (_isGetObserver(key)) {
				return Reflect.get(target, key);
			}
			// debugger;
			//-------------
			// debugger;
			let value = Reflect.get(target, key);
			let ob = _getOb(target);
			//-------------
			_emit('get', ob, target, key);

			return value;
		},
		// set
		set(target, key, value) {
			console.log(`obj.set(${$toString(key)})`);
			debugger;
			let prevValue = target[key];

			// 會比較浪費時間去比較
			const $isEqaulValue = _isEqualValue(prevValue, value);
			debugger;
			if ($isEqaulValue) {
				return true;
			}
			//-------------
			let ob = _getOb(target);
			let prevOb = _getOb(prevValue);
			let isAdd = !(key in target);
			//-------------
			if (prevOb != null) {
				debugger;
				prevOb.remove();
				debugger;
			}
			//-------------
			// debugger;
			let {
				proxy = null,
					value: $value,
			} = $react._createOb(value, $this);

			target[key] = (proxy != null) ? proxy : $value;
			//-------------
			_emit('set', ob, target, key);
			if (isAdd) {
				_emit('set.length', ob, target, key);
			}

			return true;
		},
		// has
		has(target, key) {
			console.log(`obj.has(${$toString(key)})`);
			// debugger;

			let ob = _getOb(target);
			let res = Reflect.has(target, key);
			//-------------
			let isEmit = !$tools.isGetObserver(key);
			_emit('has', ob, target, key, isEmit);
			return res;
		},
		// ownKeys
		ownKeys(target) {
			console.log('obj.ownKeys()');
			// debugger;
			// 攔截 {}.loop
			let ob = _getOb(target);
			let keys = Reflect.ownKeys(target);

			_emit('ownKeys', ob, target, null);
			return keys
		},
		// delete
		deleteProperty(target, key) {
			console.log(`obj.delete(${$toString(key)})`);
			debugger;

			if (!Reflect.has(target, key)) {
				return true;
			}
			//-------------
			let value = Reflect.get(target, key);
			let ob = _getOb(target);
			let preOb = _getOb(value);

			let res = Reflect.deleteProperty(target, key);
			if (!res) {
				return res;
			}
			//-------------
			if (preOb != null) {
				preOb.remove();
				debugger;
			}
			//-------------
			_emit('delete', ob, target, key);

			_emit('delete.length', ob, target, key);
			return res;
		}
	};
}
//----------------------------

// 初級過濾
function _emit(type, ob, target, key, isEmit = true) {
	// debugger;

	if (!isEmit) {
		return;
	}
  
	if (key != null) {
		let value_type = typeof(target[key]);
		switch (value_type) {
			case 'function':
				// 取得方法
				return;
				break;
			default:
				break;
		}
		let key_type = typeof(key);
		if (key_type == 'symbol') {
			return;
		}
	}
	//-------------
	let action;
	// 資訊整理
	switch (type) {
		case 'get':
			action = 'read';
			break;
		case 'set':
			action = 'set';
			break;
		case 'set.length':
			action = 'set';
			key = 'length';
			break;
		case 'has':
			action = 'read';
			break;
		case 'ownKeys':
			action = 'read';
			key = 'length';
			break;
		case 'delete':
			action = 'set';
			break;
		case 'delete.length':
			action = 'set';
			key = 'length';
			break;
		default:
			throw new Error('...');
			break;
	}
	//-------------
	ob.emit({
		key,
		action,
		ob,
	});
}
//----------------------------
// for test
function $toString(value) {
	const $tools = $MB.get('tools');
	return $tools.toString(value);
}
//----------------------------
// 判斷 key 是否是要取得 rawData
function _isGetRawdata(key) {
	const $tools = $MB.get('tools');
	return $tools.isGetRawdata(key);
}
//----------------------------
// 判斷 key 是否是要取得 observer
function _isGetObserver(key) {
	const $tools = $MB.get('tools');
	return $tools.isGetObserver(key);
}
//----------------------------
// 取得 observe
function _getOb(data) {
	const $tools = $MB.get('tools');
	return $tools.getObserver(data);
}
//----------------------------
function _isEqualValue(oldData, newData) {
	const $tools = $MB.get('tools');
	let res = $tools.isEqualValue(oldData, newData);
	return res;
}
//----------------------------

export function handle(mb) {
	$MB = mb;
	return get_objProxySetting;
}
