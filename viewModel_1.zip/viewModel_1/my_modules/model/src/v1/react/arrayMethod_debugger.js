//debugger;

let $MB;
const $arrayProto = Array.prototype;
let $arrayProtoClone;
//------------------
let $excludedList = [
	'constructor'
]
// 搜索
const $methods_1 = [
	'find',
	'findIndex',
	'findLast',
	'findLastIndex',
	'includes',
	'indexOf',
	'lastIndexOf'
];

// 修改
const $methods_2 = [
	'push',
	'pop',
	'shift',
	'unshift',
	'splice',
	'reverse',
	'sort',
	'fill',
	'copyWithin',
];

// 特殊
const $methods_3 = ['at'];

$excludedList = $excludedList.concat($methods_1);
$excludedList = $excludedList.concat($methods_2);
$excludedList = $excludedList.concat($methods_3);
//------------------
const $otherMethods = (() => {
	let data = [];
	let arrayAttrs = Object.getOwnPropertyNames($arrayProto);
	let arrayFuns = arrayAttrs.filter((name) => {
		if (typeof(data[name]) != 'function') {
			return false;
		}
		if ($excludedList.includes(name)) {
			return false;
		}
		return true;
	});

	return arrayFuns;
})();

console.log('array.otherFuns = ' + JSON.stringify($otherMethods));

// $otherMethods
["concat", "slice", "join", "keys", "entries", "values", "forEach", "filter",
	"flat", "flatMap", "map", "every", "some", "reduce", "reduceRight", "toReversed", "toSorted", "toSpliced", "with",
	"toLocaleString", "toString"
];
//------------------
// 定義 prop 的方法
function defProperty(obj, attrName, fn) {
	Object.defineProperty(obj, attrName, {
		value: fn,
		writable: false,
		configurable: false,
		enumerable: false,
	});
}
//----------------------------
// API
function getArrayProto() {
	// debugger;
	if ($arrayProtoClone != null) {
		return $arrayProtoClone;
	}
	//-------------
	const $tools = $MB.get('tools');

	// init $arrayProtoClone
	$arrayProtoClone = Object.create($arrayProto);
	//-------------
	(() => {
		// debugger;
		// 針對 arrya.search
		let list = $methods_1;
		while (list.length > 0) {
			let method = list.pop();
			const $origin = $arrayProto[method];
			//-------------
			defProperty($arrayProtoClone, method, function(...args) {
				debugger;

				console.log(`array.${method}`);
				// console.dir(args);
				let raw = $tools.getRawData(this);
				let ob = $tools.getObserver(this);

				ob.$prevLength = raw.length;
				ob.$arrayMethod = method;
				let res = $origin.apply(this, args);
				debugger;
				ob.$prevLength = raw.length;
				ob.$arrayMethod = undefined;
				debugger;
				//-------------
				// 可以讓所有所屬數據都激起依賴信號
				// search 的結果依賴於所有的子數據
				for (let i = 0; i < this.length; i++) {
					this[i];
				}
				//-------------
				return res;
			}); // def
		} // while
	})();
	//----------------------------
	(() => {
		let list = $methods_2;

		// 針對 array 的修改方法
		while (list.length > 0) {
			let method = list.pop();
			const $origin = $arrayProto[method];
			//-------------
			defProperty($arrayProtoClone, method, function(...args) {

				debugger;
				console.log(`array.${method}`);
				// console.dir(args);

				let raw = $tools.getRawData(this);
				let ob = $tools.getObserver(this);
				//-------------
				// 當 proxy.set.length 時
				// 讀取的 prevLength 會不正確
				ob.$prevLength = raw.length;

				switch (method) {
					case 'fill':
						break;
					case 'copyWithin':
						throw new Error('no support array.copyWithin()');
						break;
					default:
						ob.$arrayMethod = method;
						break;
				}
				//-------------
				let value = $origin.apply(this, args);
				//-------------
				debugger;

				ob.$arrayMethod = undefined;
				ob.$prevLength = raw.length;

				debugger;
				switch (method) {
					case 'splice':
					case 'pop':
					case 'shift':
						$deleteOb(value);
						break;
				}
				//-------------
				return value;
			}); // def
		} // while
	})();
	//----------------------------
	(() => {
		// 針對特殊 method
		let list = $methods_3;
		while (list.length > 0) {
			let method = list.pop();
			const $origin = $arrayProto[method];
			//-------------
			defProperty($arrayProtoClone, method, function(...args) {
				debugger;
				console.log(`array.${method}`);
				// console.dir(args);

				let raw = $tools.getRawData(this);
				let ob = $tools.getObserver(this);
				//-------------
				debugger;
				ob.$prevLength = raw.length;
				ob.$arrayMethod = method;
				let res = $origin.apply(this, args);
				ob.$prevLength = raw.length;
				ob.$arrayMethod = undefined;
				//-------------
				return res;
			}); // def
		} // while
	})();
	//----------------------------
	// 其他的 array.method
	(() => {
		// debugger;

		while ($otherMethods.length > 0) {
			// debugger;
			let method = $otherMethods.pop();
			const $origin = $arrayProto[method];
			//-------------
			defProperty($arrayProtoClone, method, function(...args) {
				debugger;
				console.log(`array.${method}`);
				// console.dir(args);

				let raw = $tools.getRawData(this);
				let ob = $tools.getObserver(this);
				//-------------
				ob.$prevLength = raw.length;
				ob.$arrayMethod = method;
				let res = $origin.apply(this, args);
				// debugger;
				ob.$prevLength = raw.length;
				ob.$arrayMethod = undefined;
				//-------------
				return res;
			}); // def
		} // while
	})();
	//----------------------------
	return $arrayProtoClone;
}
//------------------
// 當數據被刪除，通知 observer
function $deleteOb(list) {
	debugger;
	const $tools = $MB.get('tools');
	//-------------
	if (!Array.isArray(list)) {
		list = [list];
	}
	while (list.length > 0) {
		debugger;
		let value = list.pop();
		let ob = $tools.getObserver(value);
		if (ob != null) {
			ob.remove();
		}
	} // while
}
//------------------
export function handle(mb) {
	$MB = mb;
	return getArrayProto;
}
