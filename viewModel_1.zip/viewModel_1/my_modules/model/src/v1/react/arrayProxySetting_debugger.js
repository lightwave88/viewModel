let $MB;

const $reg_1 = /^length$/;
const $reg_2 = /^\d+$/;
//------------------
function get_arrayProxySetting($this) {

	// const $tools = $MB.get('tools');
	const $react = $MB.get('react');

	return {
		// get
		get(target, key) {
			console.log(`array.get(${$toString(key)})`);

			// 是否要取得 rawData
			if (_isGetRawdata(key)) {
				return target;
			}
			// 是否要取得 observer
			if (_isGetObserver(key)) {
				return Reflect.get(target, key);
			}
			//-------------
			// debugger;
			let value = Reflect.get(target, key);
			let ob = _getOb(target);
			_emit('get', ob, target, key);
			return value;
		},
		// set
		set(target, key, value) {
			console.log(`array.set(${$toString(key)})`);
			debugger;

			let prevValue = target[key];
			//--------
			let ob = _getOb(target);
			let prevOb = _getOb(prevValue);

			const isLengthKey = $reg_1.test(key);
			const isIndexKey = $reg_2.test(key);
			const $hasArrayMethod = (ob.arrayMethod != null);

			let $setRes;
			let $isEmit = true;

			if (isLengthKey) {
				// type_1

				// 修改 length
				if ($hasArrayMethod) {
					// 若是取得現在的 value 是已經經過
					// arrayMethod 修改過的值，會不正確
					prevValue = ob.prevLength;
				} else {
					// 直接變動 array.length
					_setLength(target, ob, prevValue, value);
					debugger;
				}

				if (prevValue == value) {
					$isEmit = false;
				}
				$setRes = Reflect.set(target, key, value);

			} else if (isIndexKey) {
				// type_2

				debugger;
				if (!$hasArrayMethod) {
					// 會比較浪費時間去比較
					let isEqaulValue = _isEqualValue(prevValue, value);
					if (isEqaulValue) {
						return true;
					}
				}
				//-------------
				// 修改 index
				debugger;
				if (prevOb != null) {
					if ($hasArrayMethod) {
						// prevOb.romeveParent();
					} else {
						prevOb.remove();
					}
				}
				//-------------
				let {
					proxy = null,
						value: $value,
				} = $react._createOb(value, $this);
				debugger;

				let setValue = (proxy != null) ? proxy : $value;
				$setRes = Reflect.set(target, key, setValue);
			} else {
				// type_3

				// 非整規數據設定
				let isEqaulValue = _isEqualValue(prevValue, value);
				if (isEqaulValue) {
					return true;
				}
				$setRes = Reflect.set(target, key, setValue);
			}
			//-------------
			$isEmit = ($isEmit && $setRes);
			_emit('set', ob, target, key, $isEmit);

			return $setRes;
		},
		// has
		has(target, key) {
			console.log(`array.has(${$toString(key)})`);
			// debugger;

			let ob = _getOb(target);
			let res = Reflect.has(target, key);
			//-------------
			// let isEmit = $tools.isGetObserver(key);
			_emit('has', ob, target, key);
			return res;
		},
		// ownKeys
		ownKeys(target) {
			// GET
			console.log('array.ownKeys()');
			// debugger;

			// let ob = _getOb(target);
			let res = Reflect.ownKeys(target);
			//-------------
			// _emit('ownKeys', ob, target, key, []);
			return res;
		},
		// deleteProperty
		deleteProperty(target, key) {
			console.log(`array.delete(${$toString(key)})`);
			debugger;

			if (!Reflect.has(target, key)) {
				return true;
			}
			//-------------
			let ob = _getOb(target);
			let value = Reflect.get(target, key);
			let prevOb = _getOb(value);
			let $hasArrayMethod = (ob.arrayMethod != null);

			let res = Reflect.deleteProperty(target, key);
			if (!res) {
				return res;
			}
			if (!$hasArrayMethod && prevOb != null) {
				prevOb.remove();
			}
			//-------------
			_emit('delete', ob, target, key);
			return res;
		},
	};
}
//----------------------------
// 把資訊傳給 observer
function _emit(type, ob, target, key, isEmit = true) {
	// debugger;
	if (!isEmit) {
		return;
	}
	// 是否有執行 array.method
	const arrayMethod = ob.arrayMethod;
	// console.log(`arrayMethod: ${arrayMethod}`);

	if (key != null) {
		let value_type = typeof(target[key]);
		switch (value_type) {
			case 'function':
				// 取得方法
				return;
				break;
			default:
				break;
		}
		let key_type = typeof(key);
		if (key_type == 'symbol') {
			return;
		}
		//-------------
		if (key == 'length') {
			switch (arrayMethod) {
				case 'at':
					// [].at 會檢查 [].length
					// 不需要 emit
					return;
					break;
			} // switch
		}
	}
	//-------------
	// emit...
	// debugger;
	let action;

	switch (type) {
		case 'get':
		case 'has':
		case 'ownKeys':
			action = 'read';
			break;
		case 'set':
		case 'delete':
			action = 'set';
			break;
	}
	//-------------
	// debugger;
	ob.emit({
		key,
		action,
		ob,
	});
}
//----------------------------
function $toString(value) {
	const $tools = $MB.get('tools');
	return $tools.toString(value);
}
//----------------------------
// 判斷 key 是否是要取得 rawData
function _isGetRawdata(key) {
	const $tools = $MB.get('tools');
	return $tools.isGetRawdata(key);
}
//----------------------------
// 判斷 key 是否是要取得 observer
function _isGetObserver(key) {
	const $tools = $MB.get('tools');
	return $tools.isGetObserver(key);
}
//----------------------------
// 取得 observe
function _getOb(data) {
	const $tools = $MB.get('tools');
	return $tools.getObserver(data);
}

//----------------------------
function _hasObserve(data) {
	const $tools = $MB.get('tools');
	return $tools.hasObserver(data);
}
//----------------------------
// 因應直接修改 [].length
function _setLength(target, ob, prevLength, length) {
	debugger;

	if (ob.arrayMethod != null) {
		return;
	}
	const $tools = $MB.get('tools');

	if (length < prevLength) {
		// [] decrease
		for (let i = length; i < prevLength; i++) {
			debugger;
			let value = target[i];
			let child_ob = $tools.getObserver(value);
			if (child_ob != null) {
				child_ob.remove();
			}
			_emit('delete', ob, target, i);
		}
	}
}
//----------------------------
function _isEqualValue(oldData, newData) {
	const $tools = $MB.get('tools');
	let res = $tools.isEqualValue(oldData, newData);
	return res;
}
//----------------------------

export function handle(mb) {
	$MB = mb;
	return get_arrayProxySetting;
}
