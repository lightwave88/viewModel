let $MB;

const $tools = {};
//-----------------------
$tools.toString = function(value) {
  // debugger;
  let isOk = false;
  let res;
  try {
    isOk = true;
    res = value.toString();
  } catch (e) {}
  if (isOk) {
    return res;
  }
  //-------------
  try {
    isOk = true;
    res = value.valueOf();
  } catch (e) {}
  if (isOk) {
    return res;
  }
  //-------------
  res = ('' + value);
  return res;
};
//-----------------------
$tools.isPlainObject = (() => {

  const $reg_1 = /^\[object Object\]$/;
  const $proto_toString = Object.prototype.toString;
  const $plainObject = {};
  const $constructor = $plainObject.constructor;
  const $hasOwn = Object.prototype.hasOwnProperty;

  function isPlainObject(data) {
    // debugger;
    let type = typeof(data);

    if (data == null || type != 'object') {
      return false;
    }
    //-------------
    let typeString = $proto_toString.call(data);
    if (!$reg_1.test(typeString)) {
      return false;
    }
    //-------------
    // 比較 instanceObject 與 {} 的差異
    // 比較他們 proto.constructor
    const proto = Object.getPrototypeOf(data);
    if (proto == null) {
      // Object.create(null)
      return true;
    }
    if (!$hasOwn.call(proto, 'constructor')) {
      return false;
    }
    if (proto.constructor !== $constructor) {
      return false;
    }
    return true;
  };
  //-------------
  return isPlainObject;
})();
//-----------------------
export function handle(mb) {
  $MB = mb;
  return $tools;
};
