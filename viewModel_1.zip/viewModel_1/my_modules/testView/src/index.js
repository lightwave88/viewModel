import MB from '../moduleBridge.js';
const $mb = new MB();

import {
	handle as h_tools
} from './tools.js';
$mb.importHandle('tools', h_tools)

import {
	handle as h_bracket
} from './viewBracket.js';
$mb.importHandle(['viewBracket', 'Loader'], h_bracket);

import {
	handle as h_view
} from './view.js';
$mb.importHandle('View', h_view);

import {
	handle as h_api
} from './api.js';
$mb.importHandle('api', h_api);
//------------------
export function handle(bb) {
	// debugger;
	$mb.import('bb', bb);
	const api = $mb.get('api');

	bb['view'] = api;

	$mb.finish();
}
