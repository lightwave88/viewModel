let $MB;

const $delayTime = 0;
const $useRandomTime = false;

let $viewBracket_singleton;

class ViewBracket {

	$bracket = {};
	//------------------
	static singleton() {
		if ($viewBracket_singleton == null) {
			$viewBracket_singleton = new ViewBracket();
		}
		return $viewBracket_singleton;
	}
	//------------------
	constructor() {}
	//------------------
	add(name, setting = {}) {
		this.$bracket[name] = new Loader(name, setting);
	}
	//------------------
	get(name) {
		if (!(name in this.$bracket)) {
			throw new Error('...');
		}
		return this.$bracket[name]
	}
	//------------------
	has(name) {
		return (name in this.$bracket);
	}
}
//////////////////////////////
class Loader {
	$$name;
	$$promise;
	$$setting = {};
	$$isAsync = false;
	//-----------------------
	constructor(name, setting = {}, isAsync) {

		this.$$name = name;

		// 模擬非同步
		let time = $useRandomTime ? randomValue($delayTime) : $delayTime;

		this.$$promise = new Promise(($res) => {
			console.log(`loader(${this.$$name}) delay(${time})`);

			setTimeout(() => {
				debugger;
				Object.assign(this.$$setting, setting);
				$res(this.$$setting);
			}, time);
		});
	}
	//-----------------------
	get promise() {
		return this.$$promise;
	}
	//-----------------------
}
//////////////////////////////

function randomValue(value1, value2 = null) {

	let start = 0
	let range;
	let value;

	if (value2 != null) {
		start = value1;
		if (value2 <= value1) {
			throw new Error('...');
		}
		range = value2 - value1;
		value = start + Math.random() * range;
		value = Math.floor(value);
	} else {
		range = value1;
		value = Math.random() * range;
		value = Math.floor(value);
	}
	return value;
}

export function handle(mb) {
	$MB = mb;
	let viewBracket = ViewBracket.singleton();
	return {
		viewBracket,
		Loader
	};
}
