let $MB;

let $UID = 0;
class TestView {
	$$id;
	$$model;
	$$listener;
	$$element;
	//-------------
	$$parent;
	$$childs = new Set();
	$$temp_childs = new Set();
	//-------------
	$$includes = new Map();
	$$temp_includes = new Map();
	//-------------
	$$callbacks = {
		'render': null,
	};
	$$isRemove = false;
	$$contentList = [];
	$$isInited = false;
	//-------------
	$$def_init;
	$$def_render;

	$$waitingList = [];
	//-----------------------
	constructor($extends = {}, loader = null, parent = null) {
		debugger;
		const $bb = $MB.get('bb');

		this.$$id = ('view_' + $UID++);
		this.$$def_init = $bb.$deferred();

		if (parent != null) {
			if (parent instanceof TestView) {
				this.$$parent = parent;
			} else {
				throw new TypeError('...');
			}
		}

		this.$_init($extends, loader);
	}
	//-----------------------
	get data() {
		return this.$$model.data;
	}

	get model() {
		return this.$$model;
	}

	get el() {
		return this.$$el;
	}

	get id() {
		return this.$$id;
	}

	get root() {
		let root = this;
		while (root.$$parent != null) {
			root = root.$$parent;
		}
		return root;
	}
	// test
	get initPromise(){
		return this.$$def_init.promise;
	}
	//-----------------------
	async $_init(options = {}, loader) {
		debugger;

		const $bb = $MB.get('bb');

		this.$$def_render = $bb.$deferred();

		if (loader != null) {
			let options_1 = await loader.promise;

			debugger;
			Object.assign(options, options_1);
		}
		//-------------
		this.$_setCallBacks(options);

		this.$_setModel(options);

		this.$_setElement(options);
		//-------------
		debugger;

		const ModelClass = $bb.vModel.getModelClass();
		if (!(this.$$model instanceof ModelClass)) {
			throw new TypeError('...');
		}
		debugger
		const effect = this.$$model.effect({
			context: this,
			update: (args) => {
				let pr = this.$_dataUpdate(args);
				debugger;
				return pr;
			},
			remove: () => {
				this.$_dataRemove();
			}
		});
		this.$$listener = effect();
	}
	//-----------------------
	// callback
	$_dataUpdate(args) {
		debugger;
		const $bb = $MB.get('bb');

		let {
			listener,
			handle,
		} = args;
		//-------------
		if (this.$$def_render.state != 'pending') {
			// not init
			this.$$def_render = $bb.$deferred();
		}

		let root = this.root;
		handle.addRoot(root, () => {
			debugger;
			root.$_endCallback();
		});
		//-------------
		for (let child of this.$$childs) {
			this.$$childs.delete(child);
			this.$$temp_childs.add(child);
		}
		for (let [key, list] of this.$$includes) {
			this.$$includes.delete(key);
			// list.clear();
			this.$$temp_includes.set(key, list);
		}
		this.$$contentList.length = 0;
		//-------------
		// render
		let fun = this.$$callbacks['render'];
		if (fun != null) {
			debugger;
			try {
				fun.call(this, args);
			} catch (e) {
				console.dir(e);
				throw e;
			}
		}
		debugger;
		this.$_removeNoUsedView();
		//-------------
		let pr = Promise.all(this.$$waitingList);

		pr.then(() => {
			debugger;
			this.$$waitingList.length = 0;
			this.$_render();
		}, (er) => {
			debugger;
			throw er;
		});

		debugger;
		return this.$$def_render.promise;
	}
	//-----------------------
	$_dataRemove() {
		debugger;
		this.$$isRemove = true;
		if (this.$$parent == null) {
			this.$_remove();
		}
	}
	//-----------------------
	// API
	includeView(loaderName, data) {
		debugger;
		const $api = $MB.get('viewApi');
		const $tools = $MB.get('tools');

		let child = this.$_searchCaches(loaderName, data);
		let isNew = false;

		if (child == null) {
			debugger;
			isNew = true;

			let $extends = {
				$data: data,
			};

			let loader = $api.get(loaderName);
			if (loader == null) {
				throw new Error('....');
			}
			debugger;
			child = new TestView($extends, loader, this);
		}
		//-------------
		debugger;
		this.$_recordView(loaderName, child, isNew);

		let dom = child.$_getTempContent();
		return {
			view: child,
			dom,
		};
	}

	includeViewContent(loaderName, data) {
		let {
			dom
		} = this.includeView(loaderName, data);
		return dom.innerHTML;
	}

	includeViewDom(loaderName, data) {
		let {
			dom
		} = this.includeView(loaderName, data);
		return dom;
	}
	//-----------------------
	// API
	print(text) {
		const $tools = $MB.get('tools');
		text = $tools.toString(text);
		this.$$contentList.push(text);
	}
	//-----------------------
	// API
	out(text) {
		this.print(text);
	}
	//-----------------------
	// API
	setModel(data) {
		// debugger;
		if (this.$$model != null) {
			return;
		}
		const $bb = $MB.get('bb');
		this.$$model = $bb.vModel.create(data);
	}
	//-----------------------
	commit() {
		let pr = this.$$model.commit();
		return pr;
	}
	//-----------------------
	$_setCallBacks(options = {}) {
		// debugger;

		for (let name in this.$$callbacks) {
			// debugger;
			let type = typeof(options[name]);
			if (type == 'function') {
				this.$$callbacks[name] = options[name];
			}
			delete(options[name]);
		}
	}
	//-----------------------
	$_setElement(options = {}) {
		// debugger;
		let key = 'el';
		let el;
		if (key in options) {
			el = options[key];
			delete(options[key]);

			while (true) {
				if (typeof(el) == 'function') {
					el = el.call(this);
					continue;
				}
				break;
			}
		} else {
			el = document.createElement('div');
		}
		if (!(el instanceof HTMLElement)) {
			throw new TypeError('...')
		}
		this.$$el = el;
	}
	//-----------------------
	$_setModel(options = {}) {
		// debugger;
		if (this.$$model != null) {
			return;
		}
		const $bb = $MB.get('bb');
		const $tools = $MB.get('tools');

		let key = 'data';

		if (!(key in options)) {
			return;
		}
		let data = options[key];
		delete(options[key]);
		//-------------
		// debugger;
		const ModelClass = $bb.vModel.getModelClass();

		while (true) {
			debugger;
			if (typeof(data) == 'function') {
				data = data.call(this);
				continue;
			} else if (data instanceof ModelClass) {
				break;
			} else if ($tools.isPlainObject(data)) {
				break;
			} else {
				throw new TypeError('...');
			}
		}
		this.setModel(data);
	}
	//-----------------------
	$_removeNoUsedView() {
		debugger;
		for (let child of this.$$temp_childs) {
			debugger;
			this.$$temp_childs.delete(child);
			child.$remove();
		}

		for (let [key, list] of this.$$temp_includes) {
			list.clear();
			this.$$temp_includes.delete();
		}
	}
	//-----------------------
	$_render() {
		debugger;
		const el = this.el;
		//--------
		// buildDom
		let html = this.$$contentList.join('');
		el.innerHTML = html;
		//--------
		for (let view of this.$$childs) {
			debugger;
			let id = '#' + view.$id;
			let child_el = view.$el;
			let dom = el.querySelector(id);
			if (dom == null) {
				console.log(html);
				throw new Error(`no dom(${id}) `);
			}
			dom.replaceWith(child_el);
		}

		this.$_end();
	}
	//-----------------------
	$_end() {
		debugger;
		this.$$def_render.resolve();
		if (!this.$isInited) {
			this.$isInited = true;
			this.$$def_init.resolve();
			if (this.$$parent == null) {
				this.commit();
			}
		}
	}
	//-----------------------  
	$_endCallback() {
		// only root
	}
	//-----------------------
	$_searchCaches(loaderName, data) {
		debugger;

		const $bb = $MB.get('bb');
		let ob_1 = $bb.vModel.getObserver(data);

		if (ob_1 == null) {
			throw new Error('....');
		}
		//-------------
		let childView;

		if (!this.$$temp_includes.has(loaderName)) {
			return null;
		}
		let list = this.$$temp_includes.get(loaderName);

		for (let child of list) {
			// debugger;
			if (child.$$isRemove) {
				continue;
			}
			let model = child.$model;
			let ob_2 = model.observer;

			if (ob_2.isEqual(ob_1)) {
				list.delete(child)
				childView = child;
				break;
			}
		}
		if (list.size == 0) {
			this.$$temp_includes.delete(loaderName);
		}
		// debugger;
		if (childView != null) {
			this.$$temp_childs.delete(childView);
		}
		//-------------
		return childView;
	}
	//-----------------------
	$_recordView(loaderName, view, isNew) {
		debugger;

		let pr = view.$initPromise();
		this.$$waitingList.push(pr);

		this.$$childs.add(view);

		if (!this.$$includes.has(loaderName)) {
			this.$$includes.set(loaderName, new Set());
		}
		let list = this.$$includes.get(loaderName);
		list.add(view);
	}
	//-----------------------
	$_remove() {
		// childs
		for (let child of this.$$childs) {
			debugger;
			this.$$childs.delete(child);
			child.$_remove();
		}
		//-------------
		// dom
		this.el.remove();

		// this.$_destroy();
	}
	//-----------------------
	$_destroy() {
		let names = Object.getOwnPropertyNames(this);

		while (names.length > 0) {
			let name = names.pop();
			this[name] = undefined;
			delete(this[name]);
		}
	}
	//-----------------------
}

export function handle(mb) {
	$MB = mb;
	return TestView;
}