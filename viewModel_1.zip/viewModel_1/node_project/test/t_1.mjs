import $bb from '../../my_modules/bb_core/index.mjs';

const def = $bb.deferred();


def.promise.then((data) => {
  debugger;
  console.log(data);
});


function go() {
  def.resolve('hi');

  console.log('go end');
}

go();