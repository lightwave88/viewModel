Object.assign(null, null, undefined);


