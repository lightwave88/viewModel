let data_1 = {
  get name() {
    debugger
    return 'xyz';
  }
}

console.log(data_1.name);

data_1.name = 'gg';
console.log(data_1.name);

console.dir(data_1);
