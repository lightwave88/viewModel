{
  const reg_1 = /^\[object Object\]$/;

  const proto_toString = Object.prototype.toString;
  const class2type = {};
  const class2typeCts = {}.constructor;
  const hasOwn = class2type.hasOwnProperty;

  // from jquery
  function isPlainObject(obj) {
    // debugger;
    let proto;
    let Ctor;
    let res;

    if (typeof obj != 'object') {
      return false;
    }
    // Detect obvious negatives
    // Use toString instead of jQuery.type to catch host objects
    res = proto_toString.call(obj);
    res = reg_1.test(res);

    if (!obj || !res) {
      return false;
    }
    proto = Object.getPrototypeOf(obj);

    // Objects with no prototype (e.g., `Object.create( null )`) are plain
    if (!proto) {
      return true;
    }
    // Objects with prototype are plain iff they were constructed by a global Object function
    Ctor = hasOwn.call(proto, "constructor") && proto.constructor;

    return (typeof Ctor == "function" && Ctor === class2typeCts);
  }
}

const isPlainObject = (() => {
  const $reg_1 = /^\[object Object\]$/;
  const $proto_toString = Object.prototype.toString;
  const $plainObject = {};
  const $constructor = $plainObject.constructor;
  const $hasOwn = Object.prototype.hasOwnProperty;

  return function(data) {
    debugger;
    let type = typeof(data);

    if (data == null || type != 'object') {
      return false;
    }
    //-------------
    let typeString = $proto_toString.call(data);
    if (!$reg_1.test(typeString)) {
      return false;
    }
    //-------------
    // 比較 instanceObject 與 {} 的差異
    // 比較他們 proto.constructor
    const proto = Object.getPrototypeOf(data);
    if (proto == null) {
      // Object.create(null)
      return true;
    }
    if (!$hasOwn.call(proto, 'constructor')) {
      return false;
    }
    if (proto.constructor !== $constructor) {
      return false;
    }
    return true;
  };
})();

class A {};

let dataList = [null, undefined, {},
  [], new A(), Object.create(null)
];

while (dataList.length > 0) {
  debugger;
  let data = dataList.pop();
  isPlainObject(data);
}
